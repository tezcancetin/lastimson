import { Tabs } from 'expo-router';
import { Chrome as Home, Navigation, Phone, UtensilsCrossed, Route, MapPin, Truck, Bus } from 'lucide-react-native';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: '#DC2626',
        tabBarInactiveTintColor: '#6B7280',
        tabBarStyle: {
          backgroundColor: '#FFFFFF',
          borderTopWidth: 1,
          borderTopColor: '#E5E7EB',
          height: 70,
          paddingBottom: 12,
          paddingTop: 6,
        },
        tabBarLabelStyle: {
          fontFamily: 'Inter-Medium',
          fontSize: 9,
          marginTop: 2,
        },
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Ana Sayfa',
          tabBarIcon: ({ size, color }) => (
            <Home size={20} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="navigation"
        options={{
          title: 'Navigasyon',
          tabBarIcon: ({ size, color }) => (
            <Navigation size={20} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="emergency"
        options={{
          title: 'Acil Yardım',
          tabBarIcon: ({ size, color }) => (
            <Phone size={20} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="restaurants"
        options={{
          title: 'Restoranlar',
          tabBarIcon: ({ size, color }) => (
            <UtensilsCrossed size={20} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="routes"
        options={{
          title: 'Güzergah',
          tabBarIcon: ({ size, color }) => (
            <Route size={20} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="places"
        options={{
          title: 'Gezilecek',
          tabBarIcon: ({ size, color }) => (
            <MapPin size={20} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="transport"
        options={{
          title: 'Nakliye',
          tabBarIcon: ({ size, color }) => (
            <Truck size={20} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="tickets"
        options={{
          title: 'Otobüs',
          tabBarIcon: ({ size, color }) => (
            <Bus size={20} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}