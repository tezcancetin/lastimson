import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { 
  Phone, 
  TriangleAlert as AlertTriangle,
  Siren,
  Car, 
  Fuel, 
  Wrench, 
  MapPin,
  Clock,
  Star,
  Shield,
  Zap,
  Users,
  Compass,
  Calendar,
  RefreshCw,
  Wifi,
  WifiOff
} from 'lucide-react-native';
import EmergencyButton from '@/components/EmergencyButton';
import ServiceProviderCard from '@/components/ServiceProviderCard';
import PrayerTimeCard from '@/components/PrayerTimeCard';
import QiblaCompass from '@/components/QiblaCompass';

interface PrayerTime {
  name: string;
  time: string;
  isNext: boolean;
  isActive: boolean;
}

export default function EmergencyScreen() {
  const [emergencyActive, setEmergencyActive] = useState(false);
  const [showEmergencyNumbers, setShowEmergencyNumbers] = useState(false);
  const [selectedTab, setSelectedTab] = useState<'emergency' | 'prayer'>('emergency');
  const [prayerTimes, setPrayerTimes] = useState<PrayerTime[]>([]);
  const [prayerLoading, setPrayerLoading] = useState(true);
  const [prayerError, setPrayerError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [prayerSubTab, setPrayerSubTab] = useState<'times' | 'qibla'>('times');

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (selectedTab === 'prayer') {
      fetchPrayerTimes();
    }
  }, [selectedTab]);

  const fetchPrayerTimes = async () => {
    setPrayerLoading(true);
    setPrayerError(null);
    
    try {
      const response = await fetch(`https://api.diyanet.gov.tr/PrayerTime/GetPrayerTimesForLocation?cityId=9541&date=${new Date().toISOString().split('T')[0]}`);
      
      if (!response.ok) {
        throw new Error('Namaz vakitleri alınamadı');
      }
      
      const data = await response.json();
      
      const times = [
        { name: 'İmsak', time: data.Imsak || '05:32', isNext: false, isActive: false },
        { name: 'Güneş', time: data.Gunes || '07:01', isNext: false, isActive: false },
        { name: 'Öğle', time: data.Ogle || '12:48', isNext: false, isActive: false },
        { name: 'İkindi', time: data.Ikindi || '15:32', isNext: false, isActive: false },
        { name: 'Akşam', time: data.Aksam || '18:12', isNext: false, isActive: false },
        { name: 'Yatsı', time: data.Yatsi || '19:45', isNext: false, isActive: false },
      ];
      
      const now = new Date();
      const currentTimeMinutes = now.getHours() * 60 + now.getMinutes();
      
      let nextPrayerIndex = -1;
      let activePrayerIndex = -1;
      
      for (let i = 0; i < times.length; i++) {
        const [hours, minutes] = times[i].time.split(':').map(Number);
        const prayerTimeMinutes = hours * 60 + minutes;
        
        if (currentTimeMinutes < prayerTimeMinutes && nextPrayerIndex === -1) {
          nextPrayerIndex = i;
          break;
        }
        
        if (currentTimeMinutes >= prayerTimeMinutes) {
          activePrayerIndex = i;
        }
      }
      
      if (nextPrayerIndex === -1) {
        nextPrayerIndex = 0;
      }
      
      if (activePrayerIndex !== -1) {
        times[activePrayerIndex].isActive = true;
      }
      if (nextPrayerIndex !== -1) {
        times[nextPrayerIndex].isNext = true;
      }
      
      setPrayerTimes(times);
      setLastUpdated(new Date());
      
    } catch (err) {
      console.error('Prayer times fetch error:', err);
      setPrayerError('Namaz vakitleri yüklenirken hata oluştu');
      
      const defaultTimes = [
        { name: 'İmsak', time: '05:32', isNext: false, isActive: false },
        { name: 'Güneş', time: '07:01', isNext: false, isActive: false },
        { name: 'Öğle', time: '12:48', isNext: false, isActive: true },
        { name: 'İkindi', time: '15:32', isNext: true, isActive: false },
        { name: 'Akşam', time: '18:12', isNext: false, isActive: false },
        { name: 'Yatsı', time: '19:45', isNext: false, isActive: false },
      ];
      setPrayerTimes(defaultTimes);
    } finally {
      setPrayerLoading(false);
    }
  };

  const handleEmergencyCall = () => {
    setShowEmergencyNumbers(!showEmergencyNumbers);
  };

  const handleServiceRequest = (service: string) => {
    Alert.alert(
      'Yardım Talebi',
      `${service} hizmeti için en yakın sağlayıcılar aranıyor...`,
      [{ text: 'Tamam' }]
    );
  };

  const handleRefreshPrayer = () => {
    fetchPrayerTimes();
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('tr-TR', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('tr-TR', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getNextPrayer = () => {
    const nextPrayer = prayerTimes.find(prayer => prayer.isNext);
    return nextPrayer || prayerTimes[0];
  };

  const calculateTimeUntilNext = () => {
    const nextPrayer = getNextPrayer();
    if (!nextPrayer) return 'Hesaplanıyor...';
    
    const now = new Date();
    const [hours, minutes] = nextPrayer.time.split(':').map(Number);
    
    let nextPrayerTime = new Date();
    nextPrayerTime.setHours(hours, minutes, 0, 0);
    
    if (nextPrayerTime <= now) {
      nextPrayerTime.setDate(nextPrayerTime.getDate() + 1);
    }
    
    const diff = nextPrayerTime.getTime() - now.getTime();
    const hoursLeft = Math.floor(diff / (1000 * 60 * 60));
    const minutesLeft = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hoursLeft} saat ${minutesLeft} dakika`;
  };

  const emergencyServices = [
    {
      title: 'Lastik Patlak',
      icon: Car,
      description: 'Lastik değişimi ve tamiri'
    },
    {
      title: 'Akü Bitti',
      icon: Fuel,
      description: 'Akü takviyesi ve değişimi'
    },
    {
      title: 'Çekme Talebi',
      icon: Wrench,
      description: 'Araç kurtarma hizmeti'
    },
    {
      title: 'Kilitçi',
      icon: Shield,
      description: 'Araç kilidi açma'
    },
    {
      title: 'Elektrik Arızası',
      icon: Zap,
      description: 'Elektrik sistemi tamiri'
    },
    {
      title: 'İbadet Hizmetleri',
      icon: CompassIcon,
      description: 'Namaz vakitleri ve kıble yönü'
    },
    {
      title: 'Genel Arıza',
      icon: AlertTriangle,
      description: 'Akü, kilitçi, elektrik ve diğer arızalar'
    }
  ];

  const nearbyProviders = [
    {
      id: '1',
      name: 'Mehmet Usta Yol Yardım',
      rating: 4.8,
      distance: '2.3 km',
      services: ['Lastik', 'Akü', 'Çekme'],
      isAvailable: true,
      phone: '+90 532 xxx xx xx',
      image: 'https://images.pexels.com/photos/5490778/pexels-photo-5490778.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: '2',
      name: 'Anadolu Yol Yardım',
      rating: 4.9,
      distance: '1.8 km',
      services: ['Lastik', 'Çekme', 'Kurtarma'],
      isAvailable: true,
      phone: '+90 532 xxx xx xx',
      image: 'https://images.pexels.com/photos/8986028/pexels-photo-8986028.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: '3',
      name: 'Hızlı Servis 24/7',
      rating: 4.7,
      distance: '4.2 km',
      services: ['Akü', 'Marş', 'Kilitçi'],
      isAvailable: true,
      phone: '+90 532 xxx xx xx',
      image: 'https://images.pexels.com/photos/3964739/pexels-photo-3964739.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  const emergencyNumbers = [
    { name: 'Polis', number: '155', color: '#3B82F6' },
    { name: 'İtfaiye', number: '110', color: '#EF4444' },
    { name: 'Ambulans', number: '112', color: '#10B981' },
    { name: 'Jandarma', number: '156', color: '#F59E0B' }
  ];

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#DC2626', '#B91C1C']}
        style={styles.compactHeader}
      >
        <View style={styles.headerContent}>
          <Siren size={32} color="#FFFFFF" />
          <Text style={styles.compactHeaderTitle}>Acil Yol Yardım</Text>
          <Text style={styles.headerSubtitle}>7/24 acil destek hizmetleri</Text>
        </View>
      </LinearGradient>

      <View style={styles.tabContainer}>
        <TouchableOpacity 
          style={[styles.tab, selectedTab === 'emergency' && styles.activeTab]}
          onPress={() => setSelectedTab('emergency')}
        >
          <Phone size={20} color={selectedTab === 'emergency' ? '#FFFFFF' : '#6B7280'} />
          <Text style={[styles.tabText, selectedTab === 'emergency' && styles.activeTabText]}>
            Acil Yardım
          </Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tab, selectedTab === 'prayer' && styles.activeTab]}
          onPress={() => setSelectedTab('prayer')}
        >
          <Compass size={20} color={selectedTab === 'prayer' ? '#FFFFFF' : '#6B7280'} />
          <Text style={[styles.tabText, selectedTab === 'prayer' && styles.activeTabText]}>
            İbadet
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
        {selectedTab === 'emergency' ? (
          <>
            <View style={styles.emergencySection}>
              <Text style={styles.sectionTitle}>Acil Durum</Text>
              
              <TouchableOpacity style={styles.emergencyCallCard} onPress={handleEmergencyCall}>
                <View style={styles.emergencyMainButton}>
                  <AlertTriangle size={32} color="#FFFFFF" />
                  <Text style={styles.emergencyMainText}>ACİL YARDIM ÇAĞIR</Text>
                </View>
              </TouchableOpacity>
              
              {showEmergencyNumbers && (
                <View style={styles.emergencyNumbersCard}>
                  <Text style={styles.emergencyNumbersTitle}>Acil Numaralar</Text>
                  <View style={styles.emergencyNumbersGrid}>
                    {emergencyNumbers.map((emergency, index) => (
                      <TouchableOpacity
                        key={index}
                        style={[styles.emergencyNumberButton, { backgroundColor: emergency.color }]}
                        onPress={() => Alert.alert('Arama', `${emergency.number} numarası aranıyor...`)}
                      >
                        <Text style={styles.emergencyNumberText}>{emergency.number}</Text>
                        <Text style={styles.emergencyNumberLabel}>{emergency.name}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              )}
            </View>

            <View style={styles.servicesSection}>
              <Text style={styles.sectionTitle}>Hızlı Yardım Hizmetleri</Text>
              <View style={styles.compactServiceGrid}>
                {emergencyServices.map((service, index) => {
                  const Icon = service.icon;
                  return (
                    <TouchableOpacity
                      key={index}
                      style={styles.compactServiceCard}
                      onPress={() => handleServiceRequest(service.title)}
                    >
                      <View style={styles.compactServiceIcon}>
                        <Icon size={24} color="#DC2626" />
                      </View>
                      <Text style={styles.compactServiceTitle}>{service.title}</Text>
                      <Text style={styles.compactServiceDescription}>{service.description}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>

            <View style={styles.providersSection}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Yakınınızdaki Sağlayıcılar</Text>
                <TouchableOpacity>
                  <Text style={styles.seeAllText}>Tümünü Gör</Text>
                </TouchableOpacity>
              </View>
              
              {nearbyProviders.map((provider) => (
                <ServiceProviderCard
                  key={provider.id}
                  provider={provider}
                  onPress={() => console.log('View provider', provider.name)}
                  onCall={() => console.log('Call provider', provider.name)}
                />
              ))}
            </View>

            <View style={styles.infoSection}>
              <View style={styles.infoCard}>
                <Users size={24} color="#3B82F6" />
                <View style={styles.infoContent}>
                  <Text style={styles.infoTitle}>7/24 Destek</Text>
                  <Text style={styles.infoText}>
                    Acil durumlarda 24 saat kesintisiz hizmet veriyoruz. 
                    Ortalama müdahale süremiz 15 dakikadır.
                  </Text>
                </View>
              </View>
            </View>

            <View style={styles.locationSection}>
              <View style={styles.locationCard}>
                <MapPin size={24} color="#DC2626" />
                <View style={styles.locationInfo}>
                  <Text style={styles.locationTitle}>Mevcut Konum</Text>
                  <Text style={styles.locationText}>İstanbul, Kadıköy</Text>
                </View>
                <TouchableOpacity style={styles.changeLocationButton}>
                  <Text style={styles.changeLocationText}>Değiştir</Text>
                </TouchableOpacity>
              </View>
            </View>
          </>
        ) : (
          <>
            {/* Prayer content would go here */}
          </>
        )}

        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  compactHeader: {
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  headerContent: {
    alignItems: 'center',
  },
  compactHeaderTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginTop: 6,
  },
  headerSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#FECACA',
    marginTop: 4,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginTop: -20,
    borderRadius: 16,
    padding: 4,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
  },
  activeTab: {
    backgroundColor: '#DC2626',
  },
  tabText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
    marginLeft: 8,
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
    marginTop: 20,
  },
  emergencySection: {
    padding: 20,
  },
  emergencyCallCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 4,
  },
  emergencyMainButton: {
    backgroundColor: '#DC2626',
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  emergencyMainText: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginLeft: 12,
  },
  emergencyNumbersCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginTop: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 3,
  },
  emergencyNumbersTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 12,
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  emergencyNumbersGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 8,
  },
  emergencyNumberButton: {
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    minWidth: '22%',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 4,
  },
  emergencyNumberText: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  emergencyNumberLabel: {
    fontSize: 10,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
    textAlign: 'center',
  },
  servicesSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  compactServiceGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  compactServiceCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    width: '48%',
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  compactServiceIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  compactServiceTitle: {
    fontSize: 13,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    textAlign: 'center',
    marginBottom: 4,
  },
  compactServiceDescription: {
    fontSize: 11,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 14,
  },
  providersSection: {
    paddingTop: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  seeAllText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#DC2626',
  },
  infoSection: {
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  infoCard: {
    backgroundColor: '#EFF6FF',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#DBEAFE',
  },
  infoContent: {
    flex: 1,
    marginLeft: 16,
  },
  infoTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1E40AF',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#1E40AF',
    lineHeight: 20,
  },
  locationSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  locationCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  locationInfo: {
    flex: 1,
    marginLeft: 12,
  },
  locationTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  locationText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 2,
  },
  changeLocationButton: {
    backgroundColor: '#FEF3F2',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  changeLocationText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#DC2626',
  },
  refreshButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#F0FDF4',
  },
  bottomPadding: {
    height: 20,
  },
});