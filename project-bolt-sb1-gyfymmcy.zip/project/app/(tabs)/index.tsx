import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { 
  Navigation, 
  Phone, 
  UtensilsCrossed, 
  Route, 
  MapPin, 
  Truck, 
  Bus, 
  Compass as CompassIcon,
  Clock,
  Calendar,
  Star,
  TrendingUp
} from 'lucide-react-native';
import TireLogo from '@/components/TireLogo';

export default function HomeScreen() {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('tr-TR', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('tr-TR', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const mainServices = [
    {
      id: 'navigation',
      title: 'Navigasyon',
      subtitle: 'GPS ve harita hizmetleri',
      icon: Navigation,
      color: '#3B82F6',
      route: '/(tabs)/navigation'
    },
    {
      id: 'emergency',
      title: 'Acil Yol Yardım',
      subtitle: '7/24 acil destek',
      icon: Phone,
      color: '#DC2626',
      route: '/(tabs)/emergency'
    },
    {
      id: 'restaurants',
      title: 'Restoranlar',
      subtitle: 'Yemek ve içecek',
      icon: UtensilsCrossed,
      color: '#F59E0B',
      route: '/(tabs)/restaurants'
    },
    {
      id: 'routes',
      title: 'Güzergah Durumu',
      subtitle: 'Trafik ve yol bilgileri',
      icon: Route,
      color: '#10B981',
      route: '/(tabs)/routes'
    },
    {
      id: 'places',
      title: 'Gezilecek Yerler',
      subtitle: 'Turistik mekanlar',
      icon: MapPin,
      color: '#8B5CF6',
      route: '/(tabs)/places'
    },
    {
      id: 'transport',
      title: 'Nakliye',
      subtitle: 'Taşımacılık hizmetleri',
      icon: Truck,
      color: '#EF4444',
      route: '/(tabs)/transport'
    },
    {
      id: 'tickets',
      title: 'Otobüs Bileti',
      subtitle: 'Bilet rezervasyonu',
      icon: Bus,
      color: '#06B6D4',
      route: '/(tabs)/tickets'
    },
  ];

  const handleServicePress = (service: any) => {
    try {
      router.push(service.route);
    } catch (error) {
      Alert.alert(
        'Yönlendirme',
        `${service.title} sayfasına yönlendiriliyorsunuz...`,
        [{ text: 'Tamam' }]
      );
    }
  };

  const quickStats = [
    { label: 'Hizmet', value: '24/7', icon: Clock },
    { label: 'Memnuniyet', value: '98%', icon: Star },
    { label: 'Nokta', value: '500+', icon: MapPin },
    { label: 'Kullanım', value: '15K+', icon: TrendingUp }
  ];

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#DC2626', '#B91C1C']}
        style={styles.compactHeader}
      >
        <View style={styles.headerContent}>
          <TireLogo size={40} color="#FFFFFF" />
          <Text style={styles.compactHeaderTitle}>LASTİM</Text>
          <Text style={styles.headerSubtitle}>Seyahat Hizmetleri</Text>
          
          <View style={styles.timeContainer}>
            <View style={styles.timeAndDateRow}>
              <View style={styles.timeSection}>
                <Clock size={20} color="#FFFFFF" />
                <Text style={styles.timeText}>{formatTime(currentTime)}</Text>
              </View>
              <View style={styles.dateSection}>
                <Calendar size={20} color="#FECACA" />
                <Text style={styles.dateText}>{formatDate(currentTime)}</Text>
              </View>
            </View>
          </View>
        </View>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
        <View style={styles.servicesSection}>
          <Text style={styles.sectionTitle}>Hizmetlerimiz</Text>
          
          <View style={styles.prayerSection}>
            <View style={styles.prayerCard}>
              <CompassIcon size={24} color="#84CC16" />
              <View style={styles.prayerInfo}>
                <Text style={styles.prayerTitle}>İbadet Hizmetleri</Text>
                <Text style={styles.prayerSubtitle}>Namaz vakitleri ve kıble yönü</Text>
              </View>
              <TouchableOpacity 
                style={styles.prayerButton}
                onPress={() => router.push('/(tabs)/prayer')}
              >
                <Text style={styles.prayerButtonText}>Görüntüle</Text>
              </TouchableOpacity>
            </View>
          </View>
          
          <View style={styles.servicesGrid}>
            {mainServices.map((service) => {
              const Icon = service.icon;
              return (
                <TouchableOpacity
                  key={service.id}
                  style={styles.serviceCard}
                  onPress={() => handleServicePress(service)}
                  activeOpacity={0.7}
                >
                  <View style={[styles.serviceIcon, { backgroundColor: `${service.color}20` }]}>
                    <Icon size={28} color={service.color} />
                  </View>
                  <Text style={styles.serviceTitle}>{service.title}</Text>
                  <Text style={styles.serviceSubtitle}>{service.subtitle}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
          
          <View style={styles.locationSection}>
            <View style={styles.locationCard}>
              <MapPin size={20} color="#DC2626" />
              <View style={styles.locationInfo}>
                <Text style={styles.locationTitle}>Mevcut Konum</Text>
                <Text style={styles.locationText}>İstanbul, Kadıköy</Text>
              </View>
              <TouchableOpacity style={styles.changeLocationButton}>
                <Text style={styles.changeLocationText}>Değiştir</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <View style={styles.statsSection}>
          <Text style={styles.statsSectionTitle}>İstatistikler</Text>
          <View style={styles.statsGrid}>
            {quickStats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <View key={index} style={styles.statCard}>
                  <Icon size={18} color="#DC2626" />
                  <Text style={styles.statValue}>{stat.value}</Text>
                  <Text style={styles.statLabel}>{stat.label}</Text>
                </View>
              );
            })}
          </View>
        </View>

        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  compactHeader: {
    paddingVertical: 18,
    paddingHorizontal: 20,
  },
  headerContent: {
    alignItems: 'center',
  },
  compactHeaderTitle: {
    fontSize: 22,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginTop: 6,
  },
  headerSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#FECACA',
    marginTop: 4,
    marginBottom: 12,
  },
  timeContainer: {
    alignItems: 'center',
    width: '100%',
  },
  timeAndDateRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    paddingHorizontal: 20,
  },
  timeSection: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    flex: 1,
    marginRight: 8,
    justifyContent: 'center',
  },
  timeText: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginLeft: 8,
  },
  dateSection: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    flex: 1,
    marginLeft: 8,
    justifyContent: 'center',
  },
  dateText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#FECACA',
    marginLeft: 8,
    textAlign: 'center',
  },
  content: {
    flex: 1,
  },
  servicesSection: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  prayerSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  statsSectionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 12,
  },
  servicesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  serviceCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 12,
    alignItems: 'center',
    width: '48%',
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  serviceIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  serviceTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    textAlign: 'center',
    marginBottom: 2,
  },
  serviceSubtitle: {
    fontSize: 11,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
  },
  locationSection: {
    marginTop: 16,
  },
  locationCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 3,
  },
  locationInfo: {
    flex: 1,
    marginLeft: 8,
  },
  locationTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  locationText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 2,
  },
  changeLocationButton: {
    backgroundColor: '#FEF3F2',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  changeLocationText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#DC2626',
  },
  bottomPadding: {
    height: 20,
  },
  statsSection: {
    paddingHorizontal: 20,
    marginTop: 20,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    width: '23%',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 3,
  },
  statValue: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginTop: 4,
  },
  statLabel: {
    fontSize: 10,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 2,
  },
  prayerCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 3,
  },
  prayerInfo: {
    flex: 1,
    marginLeft: 12,
  },
  prayerTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  prayerSubtitle: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 2,
  },
  prayerButton: {
    backgroundColor: '#F0FDF4',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  prayerButtonText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#84CC16',
  }
});