import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { 
  Navigation, 
  MapPin, 
  Search, 
  Clock, 
  Route, 
  Compass, 
  Car,
  Bike,
  Footprints,
  ArrowRight,
  Star,
  Fuel
} from 'lucide-react-native';

export default function NavigationScreen() {
  const [fromLocation, setFromLocation] = useState('');
  const [toLocation, setToLocation] = useState('');
  const [selectedMode, setSelectedMode] = useState<'car' | 'bike' | 'walk'>('car');

  const transportModes = [
    { id: 'car', label: 'Araba', icon: Car, color: '#3B82F6' },
    { id: 'bike', label: 'Bisiklet', icon: Bike, color: '#10B981' },
    { id: 'walk', label: 'Yürüyüş', icon: Footprints, color: '#F59E0B' }
  ];

  const popularDestinations = [
    { name: 'İstanbul Havalimanı', distance: '45 km', time: '35 dk' },
    { name: 'Taksim Meydanı', distance: '12 km', time: '18 dk' },
    { name: 'Galata Kulesi', distance: '8 km', time: '15 dk' },
    { name: 'Sultanahmet Camii', distance: '6 km', time: '12 dk' },
    { name: 'Kapalıçarşı', distance: '7 km', time: '14 dk' },
    { name: 'Boğaziçi Köprüsü', distance: '10 km', time: '16 dk' }
  ];

  const handleSearch = () => {
    if (!fromLocation || !toLocation) {
      Alert.alert('Uyarı', 'Lütfen başlangıç ve varış noktalarını girin.');
      return;
    }
    Alert.alert('Navigasyon', 'Güzergah hesaplanıyor...');
  };

  const handleDestinationSelect = (destination: any) => {
    setToLocation(destination.name);
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#3B82F6', '#2563EB']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <Navigation size={40} color="#FFFFFF" />
          <Text style={styles.headerTitle}>Navigasyon</Text>
          <Text style={styles.headerSubtitle}>GPS ve harita hizmetleri</Text>
        </View>
      </LinearGradient>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.searchSection}>
          <Text style={styles.sectionTitle}>Güzergah Planlama</Text>
          
          <View style={styles.locationInputContainer}>
            <View style={styles.inputWrapper}>
              <MapPin size={20} color="#10B981" />
              <TextInput
                style={styles.locationInput}
                placeholder="Nereden..."
                value={fromLocation}
                onChangeText={setFromLocation}
              />
            </View>
            
            <View style={styles.routeConnector}>
              <ArrowRight size={24} color="#6B7280" />
            </View>
            
            <View style={styles.inputWrapper}>
              <MapPin size={20} color="#DC2626" />
              <TextInput
                style={styles.locationInput}
                placeholder="Nereye..."
                value={toLocation}
                onChangeText={setToLocation}
              />
            </View>
          </View>

          <View style={styles.transportModes}>
            {transportModes.map((mode) => {
              const Icon = mode.icon;
              return (
                <TouchableOpacity
                  key={mode.id}
                  style={[
                    styles.modeButton,
                    selectedMode === mode.id && styles.activeModeButton
                  ]}
                  onPress={() => setSelectedMode(mode.id as any)}
                >
                  <Icon 
                    size={24} 
                    color={selectedMode === mode.id ? '#FFFFFF' : mode.color} 
                  />
                  <Text style={[
                    styles.modeText,
                    selectedMode === mode.id && styles.activeModeText
                  ]}>
                    {mode.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
          
          <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
            <Search size={20} color="#FFFFFF" />
            <Text style={styles.searchButtonText}>Güzergah Bul</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.popularSection}>
          <Text style={styles.sectionTitle}>Popüler Destinasyonlar</Text>
          
          {popularDestinations.map((destination, index) => (
            <TouchableOpacity
              key={index}
              style={styles.destinationCard}
              onPress={() => handleDestinationSelect(destination)}
            >
              <View style={styles.destinationIcon}>
                <MapPin size={20} color="#3B82F6" />
              </View>
              <View style={styles.destinationInfo}>
                <Text style={styles.destinationName}>{destination.name}</Text>
                <View style={styles.destinationMeta}>
                  <View style={styles.metaItem}>
                    <Route size={14} color="#6B7280" />
                    <Text style={styles.metaText}>{destination.distance}</Text>
                  </View>
                  <View style={styles.metaItem}>
                    <Clock size={14} color="#6B7280" />
                    <Text style={styles.metaText}>{destination.time}</Text>
                  </View>
                </View>
              </View>
              <ArrowRight size={20} color="#9CA3AF" />
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.featuresSection}>
          <Text style={styles.sectionTitle}>Navigasyon Özellikleri</Text>
          
          <View style={styles.featureGrid}>
            <View style={styles.featureCard}>
              <Compass size={32} color="#10B981" />
              <Text style={styles.featureTitle}>Gerçek Zamanlı</Text>
              <Text style={styles.featureText}>Canlı trafik bilgileri</Text>
            </View>
            
            <View style={styles.featureCard}>
              <Fuel size={32} color="#F59E0B" />
              <Text style={styles.featureTitle}>Yakıt Tasarrufu</Text>
              <Text style={styles.featureText}>Ekonomik güzergahlar</Text>
            </View>
            
            <View style={styles.featureCard}>
              <Star size={32} color="#8B5CF6" />
              <Text style={styles.featureTitle}>Favori Yerler</Text>
              <Text style={styles.featureText}>Hızlı erişim</Text>
            </View>
            
            <View style={styles.featureCard}>
              <Clock size={32} color="#EF4444" />
              <Text style={styles.featureTitle}>Zaman Tahmini</Text>
              <Text style={styles.featureText}>Doğru varış süresi</Text>
            </View>
          </View>
        </View>

        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingVertical: 24,
    paddingHorizontal: 20,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginTop: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#DBEAFE',
    marginTop: 4,
  },
  content: {
    flex: 1,
  },
  searchSection: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  locationInputContainer: {
    marginBottom: 16,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  locationInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  routeConnector: {
    alignItems: 'center',
    marginVertical: 4,
  },
  transportModes: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  modeButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    paddingVertical: 12,
    borderRadius: 12,
    marginHorizontal: 4,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  activeModeButton: {
    backgroundColor: '#3B82F6',
    borderColor: '#3B82F6',
  },
  modeText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 8,
  },
  activeModeText: {
    color: '#FFFFFF',
  },
  searchButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#3B82F6',
    paddingVertical: 16,
    borderRadius: 12,
  },
  searchButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
  popularSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  destinationCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 3,
  },
  destinationIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#EFF6FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  destinationInfo: {
    flex: 1,
  },
  destinationName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  destinationMeta: {
    flexDirection: 'row',
    gap: 16,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  featuresSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  featureGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  featureCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    width: '48%',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  featureTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginTop: 12,
    marginBottom: 4,
    textAlign: 'center',
  },
  featureText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
  },
  bottomPadding: {
    height: 20,
  },
});