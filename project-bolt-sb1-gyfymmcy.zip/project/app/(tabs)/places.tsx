import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { 
  MapPin, 
  Search, 
  Star, 
  Clock, 
  Camera, 
  Navigation,
  Heart,
  Filter,
  Mountain,
  Building,
  TreePine,
  Waves
} from 'lucide-react-native';

interface Place {
  id: string;
  name: string;
  category: string;
  rating: number;
  distance: string;
  openHours: string;
  image: string;
  description: string;
  isPopular: boolean;
}

export default function PlacesScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', label: 'Tümü', icon: MapPin },
    { id: 'historical', label: 'Tarihi', icon: Building },
    { id: 'nature', label: 'Doğa', icon: TreePine },
    { id: 'beach', label: 'Sahil', icon: Waves },
    { id: 'mountain', label: 'Dağ', icon: Mountain },
  ];

  const places: Place[] = [
    {
      id: '1',
      name: 'Sultanahmet Camii',
      category: 'Tarihi',
      rating: 4.8,
      distance: '2.1 km',
      openHours: '09:00 - 18:00',
      image: 'https://images.pexels.com/photos/1134176/pexels-photo-1134176.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Osmanlı mimarisinin en güzel örneklerinden biri',
      isPopular: true
    },
    {
      id: '2',
      name: 'Galata Kulesi',
      category: 'Tarihi',
      rating: 4.6,
      distance: '3.5 km',
      openHours: '09:00 - 20:00',
      image: 'https://images.pexels.com/photos/3889742/pexels-photo-3889742.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'İstanbul\'un panoramik manzarasını sunan tarihi kule',
      isPopular: true
    },
    {
      id: '3',
      name: 'Boğaziçi Köprüsü',
      category: 'Mimari',
      rating: 4.7,
      distance: '5.2 km',
      openHours: '24 Saat',
      image: 'https://images.pexels.com/photos/1486222/pexels-photo-1486222.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'İki kıtayı birleştiren muhteşem köprü',
      isPopular: false
    },
    {
      id: '4',
      name: 'Kapalıçarşı',
      category: 'Alışveriş',
      rating: 4.4,
      distance: '1.8 km',
      openHours: '09:00 - 19:00',
      image: 'https://images.pexels.com/photos/2901209/pexels-photo-2901209.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Dünyanın en eski kapalı çarşılarından biri',
      isPopular: true
    },
    {
      id: '5',
      name: 'Emirgan Korusu',
      category: 'Doğa',
      rating: 4.5,
      distance: '8.3 km',
      openHours: '06:00 - 22:00',
      image: 'https://images.pexels.com/photos/1166209/pexels-photo-1166209.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Şehrin kalbinde yeşil bir cennet',
      isPopular: false
    },
    {
      id: '6',
      name: 'Maiden\'s Tower',
      category: 'Tarihi',
      rating: 4.3,
      distance: '4.7 km',
      openHours: '09:00 - 18:30',
      image: 'https://images.pexels.com/photos/1010657/pexels-photo-1010657.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Boğaz\'ın ortasındaki efsanevi kule',
      isPopular: false
    }
  ];

  const filteredPlaces = places.filter(place => {
    const matchesSearch = place.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         place.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (selectedCategory === 'all') return matchesSearch;
    
    const categoryMap = {
      historical: ['Tarihi'],
      nature: ['Doğa'],
      beach: ['Sahil'],
      mountain: ['Dağ']
    };
    
    return matchesSearch && categoryMap[selectedCategory as keyof typeof categoryMap]?.includes(place.category);
  });

  const handleGetDirections = (place: Place) => {
    console.log('Getting directions to:', place.name);
  };

  const handleToggleFavorite = (place: Place) => {
    console.log('Toggle favorite:', place.name);
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#8B5CF6', '#7C3AED']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <MapPin size={40} color="#FFFFFF" />
          <Text style={styles.headerTitle}>Gezilecek Yerler</Text>
          <Text style={styles.headerSubtitle}>Turistik mekanlar ve öneriler</Text>
        </View>
      </LinearGradient>

      <View style={styles.searchSection}>
        <View style={styles.searchContainer}>
          <Search size={20} color="#6B7280" />
          <TextInput
            style={styles.searchInput}
            placeholder="Yer ara..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>

      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.categorySection}
        contentContainerStyle={styles.categoryContent}
      >
        {categories.map((category) => {
          const Icon = category.icon;
          return (
            <TouchableOpacity
              key={category.id}
              style={[
                styles.categoryButton,
                selectedCategory === category.id && styles.activeCategoryButton
              ]}
              onPress={() => setSelectedCategory(category.id)}
            >
              <Icon 
                size={20} 
                color={selectedCategory === category.id ? '#FFFFFF' : '#6B7280'} 
              />
              <Text style={[
                styles.categoryText,
                selectedCategory === category.id && styles.activeCategoryText
              ]}>
                {category.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      <ScrollView style={styles.placesContainer} showsVerticalScrollIndicator={false}>
        <View style={styles.resultsHeader}>
          <Text style={styles.resultsText}>
            {filteredPlaces.length} yer bulundu
          </Text>
        </View>

        {filteredPlaces.map((place) => (
          <View key={place.id} style={styles.placeCard}>
            <Image source={{ uri: place.image }} style={styles.placeImage} />
            {place.isPopular && (
              <View style={styles.popularBadge}>
                <Star size={12} color="#FFFFFF" fill="#FFFFFF" />
                <Text style={styles.popularText}>Popüler</Text>
              </View>
            )}
            
            <View style={styles.placeInfo}>
              <View style={styles.placeHeader}>
                <Text style={styles.placeName}>{place.name}</Text>
                <TouchableOpacity 
                  style={styles.favoriteButton}
                  onPress={() => handleToggleFavorite(place)}
                >
                  <Heart size={20} color="#DC2626" />
                </TouchableOpacity>
              </View>
              
              <Text style={styles.placeCategory}>{place.category}</Text>
              <Text style={styles.placeDescription}>{place.description}</Text>
              
              <View style={styles.placeMeta}>
                <View style={styles.ratingContainer}>
                  <Star size={16} color="#F59E0B" fill="#F59E0B" />
                  <Text style={styles.rating}>{place.rating}</Text>
                </View>
                
                <View style={styles.metaItem}>
                  <MapPin size={14} color="#6B7280" />
                  <Text style={styles.metaText}>{place.distance}</Text>
                </View>
                
                <View style={styles.metaItem}>
                  <Clock size={14} color="#6B7280" />
                  <Text style={styles.metaText}>{place.openHours}</Text>
                </View>
              </View>
              
              <View style={styles.actionButtons}>
                <TouchableOpacity 
                  style={styles.directionsButton}
                  onPress={() => handleGetDirections(place)}
                >
                  <Navigation size={18} color="#FFFFFF" />
                  <Text style={styles.buttonText}>Yol Tarifi</Text>
                </TouchableOpacity>
                
                <TouchableOpacity style={styles.photoButton}>
                  <Camera size={18} color="#8B5CF6" />
                  <Text style={styles.photoButtonText}>Fotoğraflar</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        ))}

        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingVertical: 24,
    paddingHorizontal: 20,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginTop: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#DDD6FE',
    marginTop: 4,
  },
  searchSection: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  categorySection: {
    backgroundColor: '#FFFFFF',
    paddingBottom: 16,
  },
  categoryContent: {
    paddingHorizontal: 20,
  },
  categoryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    marginRight: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  activeCategoryButton: {
    backgroundColor: '#8B5CF6',
    borderColor: '#8B5CF6',
  },
  categoryText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 8,
  },
  activeCategoryText: {
    color: '#FFFFFF',
  },
  placesContainer: {
    flex: 1,
  },
  resultsHeader: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  resultsText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  placeCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    margin: 16,
    marginTop: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
    overflow: 'hidden',
    position: 'relative',
  },
  placeImage: {
    width: '100%',
    height: 200,
  },
  popularBadge: {
    position: 'absolute',
    top: 12,
    right: 12,
    backgroundColor: '#F59E0B',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  popularText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontFamily: 'Inter-Bold',
    marginLeft: 4,
  },
  placeInfo: {
    padding: 16,
  },
  placeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  placeName: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    flex: 1,
  },
  favoriteButton: {
    padding: 4,
  },
  placeCategory: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#8B5CF6',
    marginBottom: 8,
  },
  placeDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 12,
    lineHeight: 20,
  },
  placeMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  rating: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 4,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  metaText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginLeft: 4,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  directionsButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#8B5CF6',
    paddingVertical: 12,
    borderRadius: 12,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
  photoButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#8B5CF6',
  },
  photoButtonText: {
    color: '#8B5CF6',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
  bottomPadding: {
    height: 20,
  },
});