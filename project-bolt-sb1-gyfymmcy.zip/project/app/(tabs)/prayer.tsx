import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Clock, MapPin, Compass, Calendar, RefreshCw, Wifi, WifiOff } from 'lucide-react-native';
import PrayerTimeCard from '@/components/PrayerTimeCard';
import QiblaCompass from '@/components/QiblaCompass';

interface PrayerTime {
  name: string;
  time: string;
  isNext: boolean;
  isActive: boolean;
}

interface DiyanetResponse {
  times: {
    [key: string]: string;
  };
  date: string;
  location: string;
}

export default function PrayerScreen() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedTab, setSelectedTab] = useState<'times' | 'qibla'>('times');
  const [prayerTimes, setPrayerTimes] = useState<PrayerTime[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [currentLocation, setCurrentLocation] = useState('İstanbul');

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    fetchPrayerTimes();
  }, [currentLocation]);

  const fetchPrayerTimes = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Diyanet İşleri Başkanlığı API'si
      const response = await fetch(`https://api.diyanet.gov.tr/PrayerTime/GetPrayerTimesForLocation?cityId=9541&date=${new Date().toISOString().split('T')[0]}`);
      
      if (!response.ok) {
        throw new Error('Namaz vakitleri alınamadı');
      }
      
      const data = await response.json();
      
      // API yanıtını işle
      const times = [
        { name: 'İmsak', time: data.Imsak || '05:32', isNext: false, isActive: false },
        { name: 'Güneş', time: data.Gunes || '07:01', isNext: false, isActive: false },
        { name: 'Öğle', time: data.Ogle || '12:48', isNext: false, isActive: false },
        { name: 'İkindi', time: data.Ikindi || '15:32', isNext: false, isActive: false },
        { name: 'Akşam', time: data.Aksam || '18:12', isNext: false, isActive: false },
        { name: 'Yatsı', time: data.Yatsi || '19:45', isNext: false, isActive: false },
      ];
      
      // Şu anki vakti belirle ve sonraki vakti işaretle
      const now = new Date();
      const currentTimeMinutes = now.getHours() * 60 + now.getMinutes();
      
      let nextPrayerIndex = -1;
      let activePrayerIndex = -1;
      
      for (let i = 0; i < times.length; i++) {
        const [hours, minutes] = times[i].time.split(':').map(Number);
        const prayerTimeMinutes = hours * 60 + minutes;
        
        if (currentTimeMinutes < prayerTimeMinutes && nextPrayerIndex === -1) {
          nextPrayerIndex = i;
          break;
        }
        
        // Aktif vakit kontrolü (son geçen vakit)
        if (currentTimeMinutes >= prayerTimeMinutes) {
          activePrayerIndex = i;
        }
      }
      
      // Eğer tüm vakitler geçtiyse, yarının ilk vakti sonraki olur
      if (nextPrayerIndex === -1) {
        nextPrayerIndex = 0;
      }
      
      // İşaretleme
      if (activePrayerIndex !== -1) {
        times[activePrayerIndex].isActive = true;
      }
      if (nextPrayerIndex !== -1) {
        times[nextPrayerIndex].isNext = true;
      }
      
      setPrayerTimes(times);
      setLastUpdated(new Date());
      
    } catch (err) {
      console.error('Prayer times fetch error:', err);
      setError('Namaz vakitleri yüklenirken hata oluştu');
      
      // Hata durumunda varsayılan vakitler
      const defaultTimes = [
        { name: 'İmsak', time: '05:32', isNext: false, isActive: false },
        { name: 'Güneş', time: '07:01', isNext: false, isActive: false },
        { name: 'Öğle', time: '12:48', isNext: false, isActive: true },
        { name: 'İkindi', time: '15:32', isNext: true, isActive: false },
        { name: 'Akşam', time: '18:12', isNext: false, isActive: false },
        { name: 'Yatsı', time: '19:45', isNext: false, isActive: false },
      ];
      setPrayerTimes(defaultTimes);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    fetchPrayerTimes();
  };

  const handleLocationChange = () => {
    Alert.alert(
      'Konum Değiştir',
      'Şu anda sadece İstanbul için namaz vakitleri desteklenmektedir.',
      [{ text: 'Tamam' }]
    );
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('tr-TR', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('tr-TR', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getNextPrayer = () => {
    const nextPrayer = prayerTimes.find(prayer => prayer.isNext);
    return nextPrayer || prayerTimes[0];
  };

  const calculateTimeUntilNext = () => {
    const nextPrayer = getNextPrayer();
    if (!nextPrayer) return 'Hesaplanıyor...';
    
    const now = new Date();
    const [hours, minutes] = nextPrayer.time.split(':').map(Number);
    
    let nextPrayerTime = new Date();
    nextPrayerTime.setHours(hours, minutes, 0, 0);
    
    // Eğer vakit bugün geçtiyse, yarına ayarla
    if (nextPrayerTime <= now) {
      nextPrayerTime.setDate(nextPrayerTime.getDate() + 1);
    }
    
    const diff = nextPrayerTime.getTime() - now.getTime();
    const hoursLeft = Math.floor(diff / (1000 * 60 * 60));
    const minutesLeft = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hoursLeft} saat ${minutesLeft} dakika`;
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#10B981', '#059669']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <Text style={styles.headerTitle}>Namaz Vakitleri</Text>
          <View style={styles.timeContainer}>
            <Clock size={20} color="#FFFFFF" />
            <Text style={styles.currentTime}>{formatTime(currentTime)}</Text>
          </View>
          <Text style={styles.currentDate}>{formatDate(currentTime)}</Text>
          
          {lastUpdated && (
            <View style={styles.updateInfo}>
              <Wifi size={16} color="#D1FAE5" />
              <Text style={styles.updateText}>
                Son güncelleme: {lastUpdated.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
              </Text>
            </View>
          )}
        </View>
      </LinearGradient>

      <View style={styles.tabContainer}>
        <TouchableOpacity 
          style={[styles.tab, selectedTab === 'times' && styles.activeTab]}
          onPress={() => setSelectedTab('times')}
        >
          <Calendar size={20} color={selectedTab === 'times' ? '#FFFFFF' : '#6B7280'} />
          <Text style={[styles.tabText, selectedTab === 'times' && styles.activeTabText]}>
            Vakitler
          </Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tab, selectedTab === 'qibla' && styles.activeTab]}
          onPress={() => setSelectedTab('qibla')}
        >
          <Compass size={20} color={selectedTab === 'qibla' ? '#FFFFFF' : '#6B7280'} />
          <Text style={[styles.tabText, selectedTab === 'qibla' && styles.activeTabText]}>
            Kıble
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {selectedTab === 'times' ? (
          <View style={styles.prayerTimesContainer}>
            <View style={styles.locationCard}>
              <MapPin size={20} color="#10B981" />
              <Text style={styles.locationText}>{currentLocation}, Türkiye</Text>
              <TouchableOpacity style={styles.refreshButton} onPress={handleRefresh}>
                <RefreshCw size={16} color="#10B981" />
              </TouchableOpacity>
            </View>

            {error && (
              <View style={styles.errorCard}>
                <WifiOff size={20} color="#EF4444" />
                <Text style={styles.errorText}>{error}</Text>
              </View>
            )}

            {loading ? (
              <View style={styles.loadingCard}>
                <RefreshCw size={24} color="#10B981" />
                <Text style={styles.loadingText}>Namaz vakitleri yükleniyor...</Text>
              </View>
            ) : (
              <View style={styles.prayerTimesGrid}>
                {prayerTimes.map((prayer, index) => (
                  <PrayerTimeCard
                    key={index}
                    name={prayer.name}
                    time={prayer.time}
                    isNext={prayer.isNext}
                    isActive={prayer.isActive}
                  />
                ))}
              </View>
            )}

            <View style={styles.infoCard}>
              <Text style={styles.infoTitle}>Bir Sonraki Namaz</Text>
              <View style={styles.nextPrayerContainer}>
                <Text style={styles.nextPrayerName}>{getNextPrayer()?.name} Namazı</Text>
                <Text style={styles.nextPrayerTime}>{getNextPrayer()?.time}</Text>
                <Text style={styles.remainingTime}>
                  Kalan süre: {calculateTimeUntilNext()}
                </Text>
              </View>
            </View>

            <View style={styles.monthlyContainer}>
              <Text style={styles.monthlyTitle}>Bu Ay</Text>
              <View style={styles.monthlyStats}>
                <View style={styles.statItem}>
                  <Text style={styles.statNumber}>30</Text>
                  <Text style={styles.statLabel}>Gün</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statNumber}>150</Text>
                  <Text style={styles.statLabel}>Vakit</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statNumber}>Diyanet</Text>
                  <Text style={styles.statLabel}>Kaynak</Text>
                </View>
              </View>
            </View>
          </View>
        ) : (
          <View style={styles.qiblaContainer}>
            <View style={styles.qiblaHeader}>
              <Text style={styles.qiblaTitle}>Kıble Yönü</Text>
              <Text style={styles.qiblaSubtitle}>
                Telefonunuzu düz tutun ve kıble yönünü bulun
              </Text>
            </View>
            
            <QiblaCompass />
            
            <View style={styles.qiblaInfo}>
              <View style={styles.qiblaInfoItem}>
                <MapPin size={16} color="#6B7280" />
                <Text style={styles.qiblaInfoText}>Kabe'ye uzaklık: 2,127 km</Text>
              </View>
              <View style={styles.qiblaInfoItem}>
                <Compass size={16} color="#6B7280" />
                <Text style={styles.qiblaInfoText}>Kıble açısı: 155°</Text>
              </View>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingVertical: 24,
    paddingHorizontal: 20,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Cairo-Bold',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  currentTime: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginLeft: 8,
  },
  currentDate: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#D1FAE5',
    marginBottom: 8,
  },
  updateInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  updateText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#D1FAE5',
    marginLeft: 6,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginTop: -20,
    borderRadius: 16,
    padding: 4,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
  },
  activeTab: {
    backgroundColor: '#10B981',
  },
  tabText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
    marginLeft: 8,
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
    marginTop: 20,
  },
  prayerTimesContainer: {
    paddingHorizontal: 20,
  },
  locationCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 3,
  },
  locationText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
    marginLeft: 12,
    flex: 1,
  },
  refreshButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#F0FDF4',
  },
  errorCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FEF2F2',
    padding: 16,
    borderRadius: 12,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#FECACA',
  },
  errorText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#EF4444',
    marginLeft: 12,
  },
  loadingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
  },
  loadingText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#10B981',
    marginLeft: 12,
  },
  prayerTimesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  infoCard: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 16,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  infoTitle: {
    fontSize: 18,
    fontFamily: 'Cairo-SemiBold',
    color: '#1F2937',
    marginBottom: 12,
  },
  nextPrayerContainer: {
    alignItems: 'center',
  },
  nextPrayerName: {
    fontSize: 20,
    fontFamily: 'Cairo-Bold',
    color: '#DC2626',
    marginBottom: 8,
  },
  nextPrayerTime: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  remainingTime: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  monthlyContainer: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 16,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  monthlyTitle: {
    fontSize: 18,
    fontFamily: 'Cairo-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  monthlyStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#10B981',
  },
  statLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginTop: 4,
  },
  qiblaContainer: {
    paddingHorizontal: 20,
  },
  qiblaHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  qiblaTitle: {
    fontSize: 24,
    fontFamily: 'Cairo-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  qiblaSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
  },
  qiblaInfo: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 16,
    marginTop: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  qiblaInfoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  qiblaInfoText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
    marginLeft: 12,
  },
});