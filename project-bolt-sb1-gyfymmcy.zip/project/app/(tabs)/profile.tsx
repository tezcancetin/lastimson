import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { User, Settings, Bell, Shield, CircleHelp as HelpCircle, LogOut, Phone, Mail, MapPin, CreditCard as Edit, Star, Car, Clock, Award } from 'lucide-react-native';
import TireLogo from '@/components/TireLogo';

export default function ProfileScreen() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [locationEnabled, setLocationEnabled] = useState(true);
  const [serviceProviderMode, setServiceProviderMode] = useState(false);

  const handleLogout = () => {
    Alert.alert(
      'Çıkış Yap',
      'Çıkış yapmak istediğinizden emin misiniz?',
      [
        { text: 'İptal', style: 'cancel' },
        { text: 'Çıkış Yap', onPress: () => console.log('Logging out...') }
      ]
    );
  };

  const handleEditProfile = () => {
    console.log('Edit profile');
  };

  const handleBecomeProvider = () => {
    Alert.alert(
      'Hizmet Sağlayıcı Ol',
      'Hizmet sağlayıcı olmak için başvuru formunu doldurmak ister misiniz?',
      [
        { text: 'İptal', style: 'cancel' },
        { text: 'Başvur', onPress: () => console.log('Navigate to provider registration') }
      ]
    );
  };

  const menuItems = [
    { 
      id: 'notifications', 
      icon: Bell, 
      title: 'Bildirimler', 
      hasSwitch: true,
      value: notificationsEnabled,
      onToggle: setNotificationsEnabled
    },
    { 
      id: 'location', 
      icon: MapPin, 
      title: 'Konum Hizmetleri', 
      hasSwitch: true,
      value: locationEnabled,
      onToggle: setLocationEnabled
    },
    { 
      id: 'provider', 
      icon: Car, 
      title: 'Hizmet Sağlayıcı Modu', 
      hasSwitch: true,
      value: serviceProviderMode,
      onToggle: setServiceProviderMode
    },
    { id: 'privacy', icon: Shield, title: 'Gizlilik ve Güvenlik' },
    { id: 'help', icon: HelpCircle, title: 'Yardım ve Destek' },
    { id: 'settings', icon: Settings, title: 'Ayarlar' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={styles.profileSection}>
            <View style={styles.avatarContainer}>
              <TireLogo size={80} color="#FFFFFF" />
            </View>
            <View style={styles.profileInfo}>
              <Text style={styles.profileName}>Ahmet Yılmaz</Text>
              <Text style={styles.profileEmail}>ahmet.yilmaz@email.com</Text>
              <Text style={styles.profilePhone}>+90 532 xxx xx xx</Text>
            </View>
            <TouchableOpacity style={styles.editButton} onPress={handleEditProfile}>
              <Edit size={20} color="#DC2626" />
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.statsSection}>
          <View style={styles.statCard}>
            <Star size={24} color="#F59E0B" fill="#F59E0B" />
            <Text style={styles.statNumber}>4.8</Text>
            <Text style={styles.statLabel}>Puan</Text>
          </View>
          <View style={styles.statCard}>
            <Car size={24} color="#10B981" />
            <Text style={styles.statNumber}>12</Text>
            <Text style={styles.statLabel}>Yardım</Text>
          </View>
          <View style={styles.statCard}>
            <Clock size={24} color="#3B82F6" />
            <Text style={styles.statNumber}>3</Text>
            <Text style={styles.statLabel}>Yıl</Text>
          </View>
          <View style={styles.statCard}>
            <Award size={24} color="#8B5CF6" />
            <Text style={styles.statNumber}>Gold</Text>
            <Text style={styles.statLabel}>Üye</Text>
          </View>
        </View>

        <View style={styles.quickActionsSection}>
          <TouchableOpacity style={styles.providerButton} onPress={handleBecomeProvider}>
            <Car size={24} color="#FFFFFF" />
            <Text style={styles.providerButtonText}>Hizmet Sağlayıcı Ol</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.menuSection}>
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <TouchableOpacity
                key={item.id}
                style={styles.menuItem}
                onPress={() => item.hasSwitch ? null : console.log(`Navigate to ${item.id}`)}
              >
                <View style={styles.menuItemLeft}>
                  <Icon size={24} color="#6B7280" />
                  <Text style={styles.menuItemText}>{item.title}</Text>
                </View>
                {item.hasSwitch ? (
                  <Switch
                    value={item.value}
                    onValueChange={item.onToggle}
                    trackColor={{ false: '#E5E7EB', true: '#FEF3F2' }}
                    thumbColor={item.value ? '#DC2626' : '#F3F4F6'}
                  />
                ) : (
                  <View style={styles.menuItemRight}>
                    <Text style={styles.menuItemArrow}>›</Text>
                  </View>
                )}
              </TouchableOpacity>
            );
          })}
        </View>

        <View style={styles.emergencySection}>
          <TouchableOpacity style={styles.emergencyCard}>
            <Phone size={24} color="#DC2626" />
            <View style={styles.emergencyInfo}>
              <Text style={styles.emergencyTitle}>Acil Durum Hattı</Text>
              <Text style={styles.emergencyNumber}>0850 xxx xx xx</Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.logoutSection}>
          <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
            <LogOut size={24} color="#EF4444" />
            <Text style={styles.logoutText}>Çıkış Yap</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>LASTİM v1.0.0</Text>
          <Text style={styles.footerSubtext}>Yol Yardım Hizmetleri</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingBottom: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  avatarContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#DC2626',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 2,
  },
  profilePhone: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  editButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#FEF3F2',
  },
  statsSection: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 20,
    justifyContent: 'space-between',
  },
  statCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 4,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 3,
  },
  statNumber: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginTop: 4,
  },
  quickActionsSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  providerButton: {
    backgroundColor: '#DC2626',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  providerButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 12,
  },
  menuSection: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 3,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  menuItemText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
    marginLeft: 16,
  },
  menuItemRight: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuItemArrow: {
    fontSize: 24,
    color: '#9CA3AF',
  },
  emergencySection: {
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  emergencyCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FECACA',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 3,
  },
  emergencyInfo: {
    marginLeft: 16,
  },
  emergencyTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  emergencyNumber: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#DC2626',
  },
  logoutSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  logoutButton: {
    backgroundColor: '#FFFFFF',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#FECACA',
  },
  logoutText: {
    color: '#EF4444',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 12,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 20,
    paddingBottom: 40,
  },
  footerText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
  },
  footerSubtext: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    marginTop: 4,
  },
});