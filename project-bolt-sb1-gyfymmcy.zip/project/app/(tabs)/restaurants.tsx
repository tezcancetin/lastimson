import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { 
  Search, 
  Filter, 
  MapPin, 
  Clock, 
  Star,
  Phone,
  Navigation
} from 'lucide-react-native';

interface Restaurant {
  id: string;
  name: string;
  cuisine: string;
  rating: number;
  distance: string;
  deliveryTime: string;
  isOpen: boolean;
  image: string;
  phone: string;
  address: string;
}

export default function RestaurantsScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', label: 'Tümü' },
    { id: 'turkish', label: 'Türk' },
    { id: 'fast-food', label: 'Fast Food' },
    { id: 'pizza', label: 'Pizza' },
    { id: 'kebab', label: 'Kebap' },
    { id: 'dessert', label: 'Tatlı' },
  ];

  const restaurants: Restaurant[] = [
    {
      id: '1',
      name: 'Sultanahmet Köftecisi',
      cuisine: 'Türk Mutfağı',
      rating: 4.8,
      distance: '1.2 km',
      deliveryTime: '25-35 dk',
      isOpen: true,
      image: 'https://images.pexels.com/photos/1639562/pexels-photo-1639562.jpeg?auto=compress&cs=tinysrgb&w=400',
      phone: '+90 212 xxx xx xx',
      address: 'Sultanahmet, İstanbul'
    },
    {
      id: '2',
      name: 'Domino\'s Pizza',
      cuisine: 'Pizza',
      rating: 4.5,
      distance: '2.1 km',
      deliveryTime: '30-45 dk',
      isOpen: true,
      image: 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg?auto=compress&cs=tinysrgb&w=400',
      phone: '+90 212 xxx xx xx',
      address: 'Kadıköy, İstanbul'
    },
    {
      id: '3',
      name: 'Dürümzade',
      cuisine: 'Kebap & Dürüm',
      rating: 4.7,
      distance: '0.8 km',
      deliveryTime: '15-25 dk',
      isOpen: false,
      image: 'https://images.pexels.com/photos/4676409/pexels-photo-4676409.jpeg?auto=compress&cs=tinysrgb&w=400',
      phone: '+90 212 xxx xx xx',
      address: 'Beyoğlu, İstanbul'
    },
    {
      id: '4',
      name: 'McDonald\'s',
      cuisine: 'Fast Food',
      rating: 4.3,
      distance: '1.5 km',
      deliveryTime: '20-30 dk',
      isOpen: true,
      image: 'https://images.pexels.com/photos/1633525/pexels-photo-1633525.jpeg?auto=compress&cs=tinysrgb&w=400',
      phone: '+90 212 xxx xx xx',
      address: 'Şişli, İstanbul'
    },
    {
      id: '5',
      name: 'Karakoy Lokantasi',
      cuisine: 'Türk Mutfağı',
      rating: 4.9,
      distance: '3.2 km',
      deliveryTime: '40-55 dk',
      isOpen: true,
      image: 'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=400',
      phone: '+90 212 xxx xx xx',
      address: 'Karaköy, İstanbul'
    },
    {
      id: '6',
      name: 'Hafiz Mustafa',
      cuisine: 'Tatlı & Baklava',
      rating: 4.6,
      distance: '2.8 km',
      deliveryTime: '35-45 dk',
      isOpen: true,
      image: 'https://images.pexels.com/photos/1126728/pexels-photo-1126728.jpeg?auto=compress&cs=tinysrgb&w=400',
      phone: '+90 212 xxx xx xx',
      address: 'Eminönü, İstanbul'
    }
  ];

  const filteredRestaurants = restaurants.filter(restaurant => {
    const matchesSearch = restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         restaurant.cuisine.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (selectedCategory === 'all') return matchesSearch;
    
    const categoryMap = {
      turkish: ['Türk Mutfağı'],
      'fast-food': ['Fast Food'],
      pizza: ['Pizza'],
      kebab: ['Kebap & Dürüm'],
      dessert: ['Tatlı & Baklava']
    };
    
    return matchesSearch && categoryMap[selectedCategory as keyof typeof categoryMap]?.includes(restaurant.cuisine);
  });

  const handleCall = (phone: string) => {
    console.log('Calling:', phone);
  };

  const handleGetDirections = (address: string) => {
    console.log('Getting directions to:', address);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Yakın Restoranlar</Text>
        <View style={styles.locationContainer}>
          <MapPin size={16} color="#6B7280" />
          <Text style={styles.locationText}>İstanbul, Kadıköy</Text>
        </View>
      </View>

      <View style={styles.searchSection}>
        <View style={styles.searchContainer}>
          <Search size={20} color="#6B7280" />
          <TextInput
            style={styles.searchInput}
            placeholder="Restoran ara..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>

      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.categorySection}
        contentContainerStyle={styles.categoryContent}
      >
        {categories.map((category) => (
          <TouchableOpacity
            key={category.id}
            style={[
              styles.categoryButton,
              selectedCategory === category.id && styles.activeCategoryButton
            ]}
            onPress={() => setSelectedCategory(category.id)}
          >
            <Text style={[
              styles.categoryText,
              selectedCategory === category.id && styles.activeCategoryText
            ]}>
              {category.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView style={styles.restaurantsContainer} showsVerticalScrollIndicator={false}>
        <View style={styles.resultsHeader}>
          <Text style={styles.resultsText}>
            {filteredRestaurants.length} restoran bulundu
          </Text>
        </View>

        {filteredRestaurants.map((restaurant) => (
          <View key={restaurant.id} style={styles.restaurantCard}>
            <Image source={{ uri: restaurant.image }} style={styles.restaurantImage} />
            <View style={styles.restaurantInfo}>
              <View style={styles.restaurantHeader}>
                <Text style={styles.restaurantName}>{restaurant.name}</Text>
                <View style={styles.statusContainer}>
                  <View style={[
                    styles.statusIndicator, 
                    { backgroundColor: restaurant.isOpen ? '#10B981' : '#EF4444' }
                  ]} />
                  <Text style={styles.statusText}>
                    {restaurant.isOpen ? 'Açık' : 'Kapalı'}
                  </Text>
                </View>
              </View>
              
              <Text style={styles.cuisineText}>{restaurant.cuisine}</Text>
              
              <View style={styles.restaurantMeta}>
                <View style={styles.ratingContainer}>
                  <Star size={16} color="#F59E0B" fill="#F59E0B" />
                  <Text style={styles.rating}>{restaurant.rating}</Text>
                </View>
                
                <View style={styles.metaItem}>
                  <MapPin size={14} color="#6B7280" />
                  <Text style={styles.metaText}>{restaurant.distance}</Text>
                </View>
                
                <View style={styles.metaItem}>
                  <Clock size={14} color="#6B7280" />
                  <Text style={styles.metaText}>{restaurant.deliveryTime}</Text>
                </View>
              </View>
              
              <Text style={styles.address}>{restaurant.address}</Text>
              
              <View style={styles.actionButtons}>
                <TouchableOpacity 
                  style={styles.callButton}
                  onPress={() => handleCall(restaurant.phone)}
                >
                  <Phone size={18} color="#FFFFFF" />
                  <Text style={styles.buttonText}>Ara</Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={styles.directionsButton}
                  onPress={() => handleGetDirections(restaurant.address)}
                >
                  <Navigation size={18} color="#DC2626" />
                  <Text style={styles.directionsButtonText}>Yol Tarifi</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        ))}

        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginLeft: 6,
  },
  searchSection: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  categorySection: {
    backgroundColor: '#FFFFFF',
    paddingBottom: 16,
  },
  categoryContent: {
    paddingHorizontal: 20,
  },
  categoryButton: {
    backgroundColor: '#F9FAFB',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    marginRight: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  activeCategoryButton: {
    backgroundColor: '#DC2626',
    borderColor: '#DC2626',
  },
  categoryText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  activeCategoryText: {
    color: '#FFFFFF',
  },
  restaurantsContainer: {
    flex: 1,
  },
  resultsHeader: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  resultsText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  restaurantCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    margin: 16,
    marginTop: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
    overflow: 'hidden',
  },
  restaurantImage: {
    width: '100%',
    height: 160,
  },
  restaurantInfo: {
    padding: 16,
  },
  restaurantHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  restaurantName: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    flex: 1,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  statusText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  cuisineText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 12,
  },
  restaurantMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  rating: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 4,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  metaText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginLeft: 4,
  },
  address: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 16,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  callButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#DC2626',
    paddingVertical: 12,
    borderRadius: 12,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
  directionsButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#DC2626',
  },
  directionsButtonText: {
    color: '#DC2626',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
  bottomPadding: {
    height: 20,
  },
});