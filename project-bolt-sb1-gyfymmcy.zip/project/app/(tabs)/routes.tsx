import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MapPin, Navigation, Clock, Cloud, Sun, CloudRain, Truck, ArrowRight, TriangleAlert as AlertTriangle, Fuel, Route as RouteIcon, Calendar, Phone, Thermometer } from 'lucide-react-native';
import RouteCard from '@/components/RouteCard';
import WeatherCard from '@/components/WeatherCard';
import TransportServiceCard from '@/components/TransportServiceCard';

interface RouteInfo {
  id: string;
  from: string;
  to: string;
  distance: string;
  duration: string;
  roadCondition: 'good' | 'moderate' | 'poor';
  trafficLevel: 'low' | 'medium' | 'high';
  tollCost: string;
  fuelCost: string;
}

interface WeatherInfo {
  location: string;
  temperature: number;
  condition: 'sunny' | 'cloudy' | 'rainy';
  humidity: number;
  windSpeed: number;
  visibility: string;
}

interface TransportService {
  id: string;
  name: string;
  type: 'moving' | 'cargo' | 'logistics';
  rating: number;
  price: string;
  capacity: string;
  phone: string;
  isAvailable: boolean;
}

export default function RoutesScreen() {
  const [fromLocation, setFromLocation] = useState('');
  const [toLocation, setToLocation] = useState('');
  const [selectedTab, setSelectedTab] = useState<'route' | 'weather' | 'transport'>('route');

  const routeInfo: RouteInfo = {
    id: '1',
    from: 'İstanbul, Kadıköy',
    to: 'Ankara, Çankaya',
    distance: '454 km',
    duration: '4 saat 32 dk',
    roadCondition: 'good',
    trafficLevel: 'medium',
    tollCost: '85 TL',
    fuelCost: '320 TL'
  };

  const weatherInfo: WeatherInfo[] = [
    {
      location: 'İstanbul (Başlangıç)',
      temperature: 18,
      condition: 'cloudy',
      humidity: 65,
      windSpeed: 12,
      visibility: '10 km'
    },
    {
      location: 'Bolu (Güzergah Üzeri)',
      temperature: 12,
      condition: 'rainy',
      humidity: 85,
      windSpeed: 18,
      visibility: '5 km'
    },
    {
      location: 'Ankara (Varış)',
      temperature: 15,
      condition: 'sunny',
      humidity: 45,
      windSpeed: 8,
      visibility: '15 km'
    }
  ];

  const transportServices: TransportService[] = [
    {
      id: '1',
      name: 'Anadolu Nakliyat',
      type: 'moving',
      rating: 4.8,
      price: '2.500 TL',
      capacity: '15 m³',
      phone: '+90 532 xxx xx xx',
      isAvailable: true
    },
    {
      id: '2',
      name: 'Hızlı Kargo',
      type: 'cargo',
      rating: 4.6,
      price: '150 TL',
      capacity: '5 m³',
      phone: '+90 532 xxx xx xx',
      isAvailable: true
    },
    {
      id: '3',
      name: 'Mega Lojistik',
      type: 'logistics',
      rating: 4.9,
      price: '5.000 TL',
      capacity: '40 m³',
      phone: '+90 532 xxx xx xx',
      isAvailable: false
    }
  ];

  const handleRouteSearch = () => {
    if (!fromLocation || !toLocation) {
      Alert.alert('Uyarı', 'Lütfen başlangıç ve varış noktalarını girin.');
      return;
    }
    Alert.alert('Güzergah Aranıyor', 'En iyi güzergah hesaplanıyor...');
  };

  const handleCallTransport = (phone: string) => {
    Alert.alert('Arama', `${phone} numarası aranıyor...`);
  };

  const getRoadConditionColor = (condition: string) => {
    switch (condition) {
      case 'good': return '#10B981';
      case 'moderate': return '#F59E0B';
      case 'poor': return '#EF4444';
      default: return '#6B7280';
    }
  };

  const getTrafficLevelColor = (level: string) => {
    switch (level) {
      case 'low': return '#10B981';
      case 'medium': return '#F59E0B';
      case 'high': return '#EF4444';
      default: return '#6B7280';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#3B82F6', '#2563EB']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <Text style={styles.headerTitle}>Güzergah & Nakliye</Text>
          <Text style={styles.headerSubtitle}>Yol durumu, hava durumu ve nakliye hizmetleri</Text>
        </View>
      </LinearGradient>

      <View style={styles.tabContainer}>
        <TouchableOpacity 
          style={[styles.tab, selectedTab === 'route' && styles.activeTab]}
          onPress={() => setSelectedTab('route')}
        >
          <RouteIcon size={20} color={selectedTab === 'route' ? '#FFFFFF' : '#6B7280'} />
          <Text style={[styles.tabText, selectedTab === 'route' && styles.activeTabText]}>
            Güzergah
          </Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tab, selectedTab === 'weather' && styles.activeTab]}
          onPress={() => setSelectedTab('weather')}
        >
          <Cloud size={20} color={selectedTab === 'weather' ? '#FFFFFF' : '#6B7280'} />
          <Text style={[styles.tabText, selectedTab === 'weather' && styles.activeTabText]}>
            Hava Durumu
          </Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tab, selectedTab === 'transport' && styles.activeTab]}
          onPress={() => setSelectedTab('transport')}
        >
          <Truck size={20} color={selectedTab === 'transport' ? '#FFFFFF' : '#6B7280'} />
          <Text style={[styles.tabText, selectedTab === 'transport' && styles.activeTabText]}>
            Nakliye
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {selectedTab === 'route' && (
          <View style={styles.routeContainer}>
            <View style={styles.searchSection}>
              <Text style={styles.sectionTitle}>Güzergah Planlama</Text>
              
              <View style={styles.locationInputContainer}>
                <View style={styles.inputWrapper}>
                  <MapPin size={20} color="#10B981" />
                  <TextInput
                    style={styles.locationInput}
                    placeholder="Nereden..."
                    value={fromLocation}
                    onChangeText={setFromLocation}
                  />
                </View>
                
                <View style={styles.routeConnector}>
                  <ArrowRight size={24} color="#6B7280" />
                </View>
                
                <View style={styles.inputWrapper}>
                  <MapPin size={20} color="#DC2626" />
                  <TextInput
                    style={styles.locationInput}
                    placeholder="Nereye..."
                    value={toLocation}
                    onChangeText={setToLocation}
                  />
                </View>
              </View>
              
              <TouchableOpacity style={styles.searchButton} onPress={handleRouteSearch}>
                <Navigation size={20} color="#FFFFFF" />
                <Text style={styles.searchButtonText}>Güzergah Bul</Text>
              </TouchableOpacity>
            </View>

            <RouteCard route={routeInfo} />

            <View style={styles.roadConditionsSection}>
              <Text style={styles.sectionTitle}>Yol Durumu</Text>
              
              <View style={styles.conditionCard}>
                <View style={styles.conditionItem}>
                  <View style={[styles.conditionIndicator, { backgroundColor: getRoadConditionColor(routeInfo.roadCondition) }]} />
                  <Text style={styles.conditionLabel}>Yol Kalitesi</Text>
                  <Text style={styles.conditionValue}>
                    {routeInfo.roadCondition === 'good' ? 'İyi' : 
                     routeInfo.roadCondition === 'moderate' ? 'Orta' : 'Kötü'}
                  </Text>
                </View>
                
                <View style={styles.conditionItem}>
                  <View style={[styles.conditionIndicator, { backgroundColor: getTrafficLevelColor(routeInfo.trafficLevel) }]} />
                  <Text style={styles.conditionLabel}>Trafik Yoğunluğu</Text>
                  <Text style={styles.conditionValue}>
                    {routeInfo.trafficLevel === 'low' ? 'Az' : 
                     routeInfo.trafficLevel === 'medium' ? 'Orta' : 'Yoğun'}
                  </Text>
                </View>
              </View>
            </View>

            <View style={styles.costsSection}>
              <Text style={styles.sectionTitle}>Maliyet Hesabı</Text>
              
              <View style={styles.costCard}>
                <View style={styles.costItem}>
                  <View style={styles.costIcon}>
                    <Navigation size={20} color="#3B82F6" />
                  </View>
                  <View style={styles.costInfo}>
                    <Text style={styles.costLabel}>Köprü/Otoyol</Text>
                    <Text style={styles.costValue}>{routeInfo.tollCost}</Text>
                  </View>
                </View>
                
                <View style={styles.costItem}>
                  <View style={styles.costIcon}>
                    <Fuel size={20} color="#F59E0B" />
                  </View>
                  <View style={styles.costInfo}>
                    <Text style={styles.costLabel}>Yakıt</Text>
                    <Text style={styles.costValue}>{routeInfo.fuelCost}</Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
        )}

        {selectedTab === 'weather' && (
          <View style={styles.weatherContainer}>
            <View style={styles.weatherHeader}>
              <Thermometer size={24} color="#3B82F6" />
              <Text style={styles.sectionTitle}>Güzergah Hava Durumu</Text>
            </View>
            <Text style={styles.sectionSubtitle}>
              Yolculuğunuz boyunca hava durumu bilgileri
            </Text>
            
            {weatherInfo.map((weather, index) => (
              <WeatherCard key={index} weather={weather} />
            ))}
            
            <View style={styles.weatherTipsCard}>
              <AlertTriangle size={24} color="#F59E0B" />
              <View style={styles.weatherTipsContent}>
                <Text style={styles.weatherTipsTitle}>Sürüş Önerileri</Text>
                <Text style={styles.weatherTipsText}>
                  • Yağmurlu havalarda hızınızı azaltın{'\n'}
                  • Sisli havalarda farlarınızı yakın{'\n'}
                  • Karlı yollarda zincir kullanın{'\n'}
                  • Uzun yolculuklarda mola verin{'\n'}
                  • Hava koşulları kötüyse yolculuğu erteleyin
                </Text>
              </View>
            </View>
          </View>
        )}

        {selectedTab === 'transport' && (
          <View style={styles.transportContainer}>
            <Text style={styles.sectionTitle}>Nakliye Hizmetleri</Text>
            <Text style={styles.sectionSubtitle}>
              Dönüş yolculuğunuz için nakliye ve taşımacılık hizmetleri
            </Text>
            
            {transportServices.map((service) => (
              <TransportServiceCard
                key={service.id}
                service={service}
                onCall={() => handleCallTransport(service.phone)}
              />
            ))}
            
            <View style={styles.transportInfoCard}>
              <Calendar size={24} color="#3B82F6" />
              <View style={styles.transportInfoContent}>
                <Text style={styles.transportInfoTitle}>Rezervasyon Önerisi</Text>
                <Text style={styles.transportInfoText}>
                  Nakliye hizmetleri için en az 24 saat önceden rezervasyon yapmanızı öneririz.
                  Özellikle hafta sonları ve tatil günlerinde erken rezervasyon önemlidir.
                </Text>
              </View>
            </View>
          </View>
        )}

        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingVertical: 24,
    paddingHorizontal: 20,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#DBEAFE',
    textAlign: 'center',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginTop: -20,
    borderRadius: 16,
    padding: 4,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
  },
  activeTab: {
    backgroundColor: '#3B82F6',
  },
  tabText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
    marginLeft: 6,
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
    marginTop: 20,
  },
  routeContainer: {
    paddingHorizontal: 20,
  },
  searchSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  sectionSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 16,
    lineHeight: 24,
  },
  locationInputContainer: {
    marginBottom: 16,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  locationInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  routeConnector: {
    alignItems: 'center',
    marginVertical: 4,
  },
  searchButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#3B82F6',
    paddingVertical: 16,
    borderRadius: 12,
  },
  searchButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
  roadConditionsSection: {
    marginBottom: 20,
  },
  conditionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  conditionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  conditionIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
  },
  conditionLabel: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
  },
  conditionValue: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  costsSection: {
    marginBottom: 20,
  },
  costCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  costItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  costIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  costInfo: {
    flex: 1,
  },
  costLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 4,
  },
  costValue: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  weatherContainer: {
    paddingHorizontal: 20,
  },
  weatherHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  weatherTipsCard: {
    backgroundColor: '#FFFBEB',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    marginTop: 20,
    borderWidth: 1,
    borderColor: '#FED7AA',
  },
  weatherTipsContent: {
    flex: 1,
    marginLeft: 16,
  },
  weatherTipsTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#92400E',
    marginBottom: 8,
  },
  weatherTipsText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#92400E',
    lineHeight: 20,
  },
  transportContainer: {
    paddingHorizontal: 20,
  },
  transportInfoCard: {
    backgroundColor: '#EFF6FF',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    marginTop: 20,
    borderWidth: 1,
    borderColor: '#DBEAFE',
  },
  transportInfoContent: {
    flex: 1,
    marginLeft: 16,
  },
  transportInfoTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1E40AF',
    marginBottom: 8,
  },
  transportInfoText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#1E40AF',
    lineHeight: 20,
  },
  bottomPadding: {
    height: 20,
  },
});