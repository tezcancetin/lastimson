import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { 
  Plus, 
  Search, 
  Filter, 
  MapPin, 
  Phone, 
  Clock,
  Star,
  Wrench,
  Car,
  Fuel,
  Settings
} from 'lucide-react-native';
import ServiceProviderCard from '@/components/ServiceProviderCard';

export default function ServicesScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');

  const filters = [
    { id: 'all', label: 'Tümü', icon: Settings },
    { id: 'tire', label: 'Lastik', icon: Car },
    { id: 'battery', label: 'Akü', icon: Fuel },
    { id: 'mechanic', label: 'Mekanik', icon: Wrench },
  ];

  const serviceProviders = [
    {
      id: '1',
      name: 'Mehmet Usta Yol Yardım',
      rating: 4.8,
      distance: '2.3 km',
      services: ['Lastik', 'Akü', 'Çekme'],
      isAvailable: true,
      phone: '+90 532 xxx xx xx',
      image: 'https://images.pexels.com/photos/5490778/pexels-photo-5490778.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: '2',
      name: 'Kartal Oto Servis',
      rating: 4.6,
      distance: '3.1 km',
      services: ['Motor', 'Fren', 'Elektrik'],
      isAvailable: false,
      phone: '+90 532 xxx xx xx',
      image: 'https://images.pexels.com/photos/3964736/pexels-photo-3964736.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: '3',
      name: 'Anadolu Yol Yardım',
      rating: 4.9,
      distance: '1.8 km',
      services: ['Lastik', 'Çekme', 'Kurtarma'],
      isAvailable: true,
      phone: '+90 532 xxx xx xx',
      image: 'https://images.pexels.com/photos/8986028/pexels-photo-8986028.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: '4',
      name: 'Hızlı Servis 24/7',
      rating: 4.7,
      distance: '4.2 km',
      services: ['Akü', 'Marş', 'Kilitçi'],
      isAvailable: true,
      phone: '+90 532 xxx xx xx',
      image: 'https://images.pexels.com/photos/3964739/pexels-photo-3964739.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  const handleBecomeProvider = () => {
    Alert.alert(
      'Hizmet Sağlayıcı Ol',
      'Hizmet sağlayıcı olmak için kayıt formunu doldurun.',
      [
        { text: 'İptal', style: 'cancel' },
        { text: 'Devam Et', onPress: () => console.log('Navigate to registration') }
      ]
    );
  };

  const filteredProviders = serviceProviders.filter(provider => {
    const matchesSearch = provider.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         provider.services.some(service => service.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (selectedFilter === 'all') return matchesSearch;
    
    const filterMap = {
      tire: 'Lastik',
      battery: 'Akü',
      mechanic: 'Motor'
    };
    
    return matchesSearch && provider.services.includes(filterMap[selectedFilter as keyof typeof filterMap]);
  });

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Hizmet Sağlayıcıları</Text>
        <TouchableOpacity style={styles.addButton} onPress={handleBecomeProvider}>
          <Plus size={20} color="#FFFFFF" />
          <Text style={styles.addButtonText}>Sağlayıcı Ol</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.searchSection}>
        <View style={styles.searchContainer}>
          <Search size={20} color="#6B7280" />
          <TextInput
            style={styles.searchInput}
            placeholder="Hizmet ara..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>

      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.filterSection}
        contentContainerStyle={styles.filterContent}
      >
        {filters.map((filter) => {
          const Icon = filter.icon;
          return (
            <TouchableOpacity
              key={filter.id}
              style={[
                styles.filterButton,
                selectedFilter === filter.id && styles.activeFilterButton
              ]}
              onPress={() => setSelectedFilter(filter.id)}
            >
              <Icon 
                size={20} 
                color={selectedFilter === filter.id ? '#FFFFFF' : '#6B7280'} 
              />
              <Text style={[
                styles.filterText,
                selectedFilter === filter.id && styles.activeFilterText
              ]}>
                {filter.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      <ScrollView style={styles.providersContainer} showsVerticalScrollIndicator={false}>
        <View style={styles.resultsHeader}>
          <Text style={styles.resultsText}>
            {filteredProviders.length} hizmet sağlayıcı bulundu
          </Text>
        </View>

        {filteredProviders.map((provider) => (
          <ServiceProviderCard
            key={provider.id}
            provider={provider}
            onPress={() => console.log('View provider', provider.name)}
            onCall={() => console.log('Call provider', provider.name)}
          />
        ))}

        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#DC2626',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
  searchSection: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  filterSection: {
    backgroundColor: '#FFFFFF',
    paddingBottom: 16,
  },
  filterContent: {
    paddingHorizontal: 20,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    marginRight: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  activeFilterButton: {
    backgroundColor: '#DC2626',
    borderColor: '#DC2626',
  },
  filterText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 8,
  },
  activeFilterText: {
    color: '#FFFFFF',
  },
  providersContainer: {
    flex: 1,
  },
  resultsHeader: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  resultsText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  bottomPadding: {
    height: 20,
  },
});