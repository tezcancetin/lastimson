import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { 
  Bus, 
  MapPin, 
  Calendar, 
  Clock, 
  Users, 
  CreditCard,
  ArrowRight,
  Star,
  Wifi,
  Coffee,
  Zap,
  Shield,
  Search
} from 'lucide-react-native';

interface BusTrip {
  id: string;
  company: string;
  departure: string;
  arrival: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  price: number;
  availableSeats: number;
  totalSeats: number;
  rating: number;
  amenities: string[];
  busType: 'standard' | 'premium' | 'luxury';
}

export default function TicketsScreen() {
  const [fromCity, setFromCity] = useState('');
  const [toCity, setToCity] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [passengerCount, setPassengerCount] = useState(1);

  const busTrips: BusTrip[] = [
    {
      id: '1',
      company: 'Metro Turizm',
      departure: 'İstanbul',
      arrival: 'Ankara',
      departureTime: '09:00',
      arrivalTime: '13:30',
      duration: '4s 30dk',
      price: 120,
      availableSeats: 15,
      totalSeats: 45,
      rating: 4.8,
      amenities: ['wifi', 'coffee', 'power', 'insurance'],
      busType: 'premium'
    },
    {
      id: '2',
      company: 'Pamukkale Turizm',
      departure: 'İstanbul',
      arrival: 'Ankara',
      departureTime: '11:30',
      arrivalTime: '16:00',
      duration: '4s 30dk',
      price: 95,
      availableSeats: 8,
      totalSeats: 45,
      rating: 4.6,
      amenities: ['wifi', 'insurance'],
      busType: 'standard'
    },
    {
      id: '3',
      company: 'Varan Turizm',
      departure: 'İstanbul',
      arrival: 'Ankara',
      departureTime: '14:15',
      arrivalTime: '18:45',
      duration: '4s 30dk',
      price: 180,
      availableSeats: 22,
      totalSeats: 30,
      rating: 4.9,
      amenities: ['wifi', 'coffee', 'power', 'insurance'],
      busType: 'luxury'
    },
    {
      id: '4',
      company: 'Kamil Koç',
      departure: 'İstanbul',
      arrival: 'Ankara',
      departureTime: '16:45',
      arrivalTime: '21:15',
      duration: '4s 30dk',
      price: 110,
      availableSeats: 12,
      totalSeats: 45,
      rating: 4.5,
      amenities: ['wifi', 'power', 'insurance'],
      busType: 'standard'
    },
    {
      id: '5',
      company: 'Ulusoy',
      departure: 'İstanbul',
      arrival: 'Ankara',
      departureTime: '20:00',
      arrivalTime: '00:30',
      duration: '4s 30dk',
      price: 140,
      availableSeats: 18,
      totalSeats: 40,
      rating: 4.7,
      amenities: ['wifi', 'coffee', 'power', 'insurance'],
      busType: 'premium'
    }
  ];

  const popularRoutes = [
    { from: 'İstanbul', to: 'Ankara', price: '95 TL\'den' },
    { from: 'İstanbul', to: 'İzmir', price: '120 TL\'den' },
    { from: 'Ankara', to: 'Antalya', price: '150 TL\'den' },
    { from: 'İstanbul', to: 'Bursa', price: '45 TL\'den' }
  ];

  const handleSearch = () => {
    if (!fromCity || !toCity) {
      Alert.alert('Uyarı', 'Lütfen kalkış ve varış şehirlerini seçin.');
      return;
    }
    Alert.alert('Arama', 'Otobüs seferleri aranıyor...');
  };

  const handleBookTicket = (trip: BusTrip) => {
    Alert.alert(
      'Bilet Rezervasyonu',
      `${trip.company} - ${trip.departureTime} seferi için rezervasyon yapmak istiyor musunuz?\n\nFiyat: ${trip.price} TL`,
      [
        { text: 'İptal', style: 'cancel' },
        { text: 'Rezervasyon Yap', onPress: () => console.log('Book ticket', trip.id) }
      ]
    );
  };

  const getBusTypeColor = (type: string) => {
    switch (type) {
      case 'luxury': return '#8B5CF6';
      case 'premium': return '#3B82F6';
      case 'standard': return '#10B981';
      default: return '#6B7280';
    }
  };

  const getBusTypeLabel = (type: string) => {
    switch (type) {
      case 'luxury': return 'Lüks';
      case 'premium': return 'Premium';
      case 'standard': return 'Standart';
      default: return 'Bilinmiyor';
    }
  };

  const getAmenityIcon = (amenity: string) => {
    switch (amenity) {
      case 'wifi': return Wifi;
      case 'coffee': return Coffee;
      case 'power': return Zap;
      case 'insurance': return Shield;
      default: return Clock;
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('tr-TR', { 
      weekday: 'short',
      day: 'numeric',
      month: 'short'
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#06B6D4', '#0891B2']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <Bus size={40} color="#FFFFFF" />
          <Text style={styles.headerTitle}>Otobüs Bileti</Text>
          <Text style={styles.headerSubtitle}>Bilet rezervasyonu ve seferler</Text>
        </View>
      </LinearGradient>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.searchSection}>
          <Text style={styles.sectionTitle}>Bilet Ara</Text>
          
          <View style={styles.routeContainer}>
            <View style={styles.inputWrapper}>
              <MapPin size={20} color="#10B981" />
              <TextInput
                style={styles.cityInput}
                placeholder="Nereden..."
                value={fromCity}
                onChangeText={setFromCity}
              />
            </View>
            
            <View style={styles.routeConnector}>
              <ArrowRight size={24} color="#6B7280" />
            </View>
            
            <View style={styles.inputWrapper}>
              <MapPin size={20} color="#DC2626" />
              <TextInput
                style={styles.cityInput}
                placeholder="Nereye..."
                value={toCity}
                onChangeText={setToCity}
              />
            </View>
          </View>

          <View style={styles.optionsContainer}>
            <TouchableOpacity style={styles.dateSelector}>
              <Calendar size={20} color="#06B6D4" />
              <Text style={styles.dateText}>{formatDate(selectedDate)}</Text>
            </TouchableOpacity>
            
            <View style={styles.passengerSelector}>
              <Users size={20} color="#06B6D4" />
              <Text style={styles.passengerText}>{passengerCount} Yolcu</Text>
            </View>
          </View>
          
          <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
            <Search size={20} color="#FFFFFF" />
            <Text style={styles.searchButtonText}>Bilet Ara</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.popularSection}>
          <Text style={styles.sectionTitle}>Popüler Güzergahlar</Text>
          
          {popularRoutes.map((route, index) => (
            <TouchableOpacity
              key={index}
              style={styles.routeCard}
              onPress={() => {
                setFromCity(route.from);
                setToCity(route.to);
              }}
            >
              <View style={styles.routeInfo}>
                <Text style={styles.routeText}>{route.from} → {route.to}</Text>
                <Text style={styles.routePrice}>{route.price}</Text>
              </View>
              <ArrowRight size={20} color="#9CA3AF" />
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.tripsSection}>
          <Text style={styles.sectionTitle}>Mevcut Seferler</Text>
          
          {busTrips.map((trip) => (
            <View key={trip.id} style={styles.tripCard}>
              <View style={styles.tripHeader}>
                <View style={styles.companyInfo}>
                  <Text style={styles.companyName}>{trip.company}</Text>
                  <View style={[styles.busTypeBadge, { backgroundColor: getBusTypeColor(trip.busType) }]}>
                    <Text style={styles.busTypeText}>{getBusTypeLabel(trip.busType)}</Text>
                  </View>
                </View>
                <View style={styles.ratingContainer}>
                  <Star size={16} color="#F59E0B" fill="#F59E0B" />
                  <Text style={styles.rating}>{trip.rating}</Text>
                </View>
              </View>

              <View style={styles.tripRoute}>
                <View style={styles.timeInfo}>
                  <Text style={styles.timeText}>{trip.departureTime}</Text>
                  <Text style={styles.cityText}>{trip.departure}</Text>
                </View>
                
                <View style={styles.routeMiddle}>
                  <View style={styles.routeLine} />
                  <Bus size={20} color="#06B6D4" />
                  <View style={styles.routeLine} />
                </View>
                
                <View style={styles.timeInfo}>
                  <Text style={styles.timeText}>{trip.arrivalTime}</Text>
                  <Text style={styles.cityText}>{trip.arrival}</Text>
                </View>
              </View>

              <View style={styles.tripDetails}>
                <View style={styles.detailItem}>
                  <Clock size={16} color="#6B7280" />
                  <Text style={styles.detailText}>{trip.duration}</Text>
                </View>
                <View style={styles.detailItem}>
                  <Users size={16} color="#6B7280" />
                  <Text style={styles.detailText}>{trip.availableSeats}/{trip.totalSeats}</Text>
                </View>
              </View>

              <View style={styles.amenitiesContainer}>
                {trip.amenities.map((amenity, index) => {
                  const Icon = getAmenityIcon(amenity);
                  return (
                    <View key={index} style={styles.amenityIcon}>
                      <Icon size={16} color="#06B6D4" />
                    </View>
                  );
                })}
              </View>

              <View style={styles.tripFooter}>
                <View style={styles.priceContainer}>
                  <Text style={styles.priceText}>{trip.price} TL</Text>
                  <Text style={styles.priceLabel}>kişi başı</Text>
                </View>
                
                <TouchableOpacity 
                  style={[styles.bookButton, trip.availableSeats === 0 && styles.disabledButton]}
                  onPress={() => handleBookTicket(trip)}
                  disabled={trip.availableSeats === 0}
                >
                  <CreditCard size={18} color="#FFFFFF" />
                  <Text style={styles.bookButtonText}>
                    {trip.availableSeats === 0 ? 'Dolu' : 'Bilet Al'}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>

        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingVertical: 24,
    paddingHorizontal: 20,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginTop: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#CFFAFE',
    marginTop: 4,
  },
  content: {
    flex: 1,
  },
  searchSection: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  routeContainer: {
    marginBottom: 16,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  cityInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  routeConnector: {
    alignItems: 'center',
    marginVertical: 4,
  },
  optionsContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  dateSelector: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  dateText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
    marginLeft: 12,
  },
  passengerSelector: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  passengerText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
    marginLeft: 12,
  },
  searchButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#06B6D4',
    paddingVertical: 16,
    borderRadius: 12,
  },
  searchButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
  popularSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  routeCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 3,
  },
  routeInfo: {
    flex: 1,
  },
  routeText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  routePrice: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#06B6D4',
  },
  tripsSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  tripCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  tripHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  companyInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  companyName: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginRight: 12,
  },
  busTypeBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  busTypeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontFamily: 'Inter-Bold',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 4,
  },
  tripRoute: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  timeInfo: {
    alignItems: 'center',
    flex: 1,
  },
  timeText: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  cityText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  routeMiddle: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 2,
    justifyContent: 'center',
  },
  routeLine: {
    height: 2,
    backgroundColor: '#E5E7EB',
    flex: 1,
  },
  tripDetails: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
    paddingVertical: 12,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  detailText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 8,
  },
  amenitiesContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 16,
    marginBottom: 16,
  },
  amenityIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F0F9FF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tripFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  priceContainer: {
    alignItems: 'flex-start',
  },
  priceText: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#06B6D4',
  },
  priceLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  bookButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#06B6D4',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  disabledButton: {
    backgroundColor: '#9CA3AF',
  },
  bookButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
  bottomPadding: {
    height: 20,
  },
});