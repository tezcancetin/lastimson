import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { 
  Truck, 
  Package, 
  Building, 
  Star, 
  Phone, 
  MapPin,
  Calendar,
  Clock,
  Weight,
  DollarSign,
  Search,
  Filter
} from 'lucide-react-native';
import TransportServiceCard from '@/components/TransportServiceCard';

interface TransportService {
  id: string;
  name: string;
  type: 'moving' | 'cargo' | 'logistics';
  rating: number;
  price: string;
  capacity: string;
  phone: string;
  isAvailable: boolean;
  specialties: string[];
  experience: string;
}

export default function TransportScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [userType, setUserType] = useState<'customer' | 'provider'>('customer');

  const serviceTypes = [
    { id: 'all', label: 'Tümü', icon: Truck },
    { id: 'moving', label: 'Ev Taşıma', icon: Truck },
    { id: 'cargo', label: 'Kargo', icon: Package },
    { id: 'logistics', label: 'Lojistik', icon: Building },
  ];

  const transportServices: TransportService[] = [
    {
      id: '1',
      name: 'Anadolu Nakliyat',
      type: 'moving',
      rating: 4.8,
      price: '2.500 TL',
      capacity: '15 m³',
      phone: '+90 532 xxx xx xx',
      isAvailable: true,
      specialties: ['Ev Taşıma', 'Ofis Taşıma', 'Ambalajlama'],
      experience: '15 yıl'
    },
    {
      id: '2',
      name: 'Hızlı Kargo',
      type: 'cargo',
      rating: 4.6,
      price: '150 TL',
      capacity: '5 m³',
      phone: '+90 532 xxx xx xx',
      isAvailable: true,
      specialties: ['Hızlı Teslimat', 'Aynı Gün', 'Kırılabilir Eşya'],
      experience: '8 yıl'
    },
    {
      id: '3',
      name: 'Mega Lojistik',
      type: 'logistics',
      rating: 4.9,
      price: '5.000 TL',
      capacity: '40 m³',
      phone: '+90 532 xxx xx xx',
      isAvailable: false,
      specialties: ['Depolama', 'Dağıtım', 'Uluslararası'],
      experience: '25 yıl'
    },
    {
      id: '4',
      name: 'Şehir İçi Taşıma',
      type: 'moving',
      rating: 4.4,
      price: '1.200 TL',
      capacity: '8 m³',
      phone: '+90 532 xxx xx xx',
      isAvailable: true,
      specialties: ['Şehir İçi', 'Küçük Eşya', 'Hızlı Servis'],
      experience: '5 yıl'
    },
    {
      id: '5',
      name: 'Express Kargo',
      type: 'cargo',
      rating: 4.7,
      price: '200 TL',
      capacity: '3 m³',
      phone: '+90 532 xxx xx xx',
      isAvailable: true,
      specialties: ['Acil Teslimat', 'Değerli Eşya', '24/7'],
      experience: '12 yıl'
    },
    {
      id: '6',
      name: 'Global Lojistik',
      type: 'logistics',
      rating: 4.5,
      price: '8.500 TL',
      capacity: '60 m³',
      phone: '+90 532 xxx xx xx',
      isAvailable: true,
      specialties: ['İhracat', 'İthalat', 'Gümrük'],
      experience: '30 yıl'
    }
  ];

  const filteredServices = transportServices.filter(service => {
    const matchesSearch = service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         service.specialties.some(specialty => 
                           specialty.toLowerCase().includes(searchQuery.toLowerCase())
                         );
    
    if (selectedType === 'all') return matchesSearch;
    return matchesSearch && service.type === selectedType;
  });

  const handleCallTransport = (phone: string) => {
    Alert.alert('Arama', `${phone} numarası aranıyor...`);
  };

  const handleRequestQuote = () => {
    Alert.alert(
      'Fiyat Teklifi',
      'Nakliye hizmeti için fiyat teklifi almak ister misiniz?',
      [
        { text: 'İptal', style: 'cancel' },
        { text: 'Teklif Al', onPress: () => console.log('Request quote') }
      ]
    );
  };

  const quickStats = [
    { label: 'Aktif Firma', value: '150+', icon: Building },
    { label: 'Günlük Taşıma', value: '500+', icon: Truck },
    { label: 'Müşteri Memnuniyeti', value: '96%', icon: Star },
    { label: 'Ortalama Süre', value: '2 Gün', icon: Clock }
  ];

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#EF4444', '#DC2626']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <Truck size={40} color="#FFFFFF" />
          <Text style={styles.headerTitle}>Nakliye Hizmetleri</Text>
          <Text style={styles.headerSubtitle}>Taşımacılık ve lojistik çözümleri</Text>
          <TouchableOpacity style={styles.headerRegisterButton}>
            <Text style={styles.headerRegisterButtonText}>Nakliyeci Kayıt</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <View style={styles.routeSection}>
        <Text style={styles.routeSectionTitle}>Nakliye Güzergahı</Text>
        <View style={styles.routeInputContainer}>
          <View style={styles.routeInputWrapper}>
            <MapPin size={16} color="#10B981" />
            <TextInput
              style={styles.routeInput}
              placeholder="Nereden..."
              value=""
              onChangeText={() => {}}
            />
          </View>
          <View style={styles.routeArrow}>
            <Text style={styles.routeArrowText}>→</Text>
          </View>
          <View style={styles.routeInputWrapper}>
            <MapPin size={16} color="#DC2626" />
            <TextInput
              style={styles.routeInput}
              placeholder="Nereye..."
              value=""
              onChangeText={() => {}}
            />
          </View>
        </View>
      </View>

      <View style={styles.searchSection}>
        <View style={styles.searchContainer}>
          <Search size={20} color="#6B7280" />
          <TextInput
            style={styles.searchInput}
            placeholder="Nakliye firması ara..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>

      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.typeSection}
        contentContainerStyle={styles.typeContent}
      >
        {serviceTypes.map((type) => {
          const Icon = type.icon;
          return (
            <TouchableOpacity
              key={type.id}
              style={[
                styles.typeButton,
                selectedType === type.id && styles.activeTypeButton
              ]}
              onPress={() => setSelectedType(type.id)}
            >
              <Icon 
                size={16} 
                color={selectedType === type.id ? '#FFFFFF' : '#6B7280'} 
              />
              <Text style={[
                styles.typeText,
                selectedType === type.id && styles.activeTypeText
              ]}>
                {type.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      <ScrollView style={styles.servicesContainer} showsVerticalScrollIndicator={false}>
        <View style={styles.resultsHeader}>
          <Text style={styles.resultsText}>
            {filteredServices.length} nakliye firması bulundu
          </Text>
          <TouchableOpacity style={styles.quoteButton} onPress={handleRequestQuote}>
            <DollarSign size={16} color="#FFFFFF" />
            <Text style={styles.quoteButtonText}>Teklif Al</Text>
          </TouchableOpacity>
        </View>

        {filteredServices.slice(0, 3).map((service) => (
          <View key={service.id} style={styles.serviceCard}>
            <View style={styles.serviceHeader}>
              <View style={styles.serviceIcon}>
                {service.type === 'moving' && <Truck size={24} color="#10B981" />}
                {service.type === 'cargo' && <Package size={24} color="#3B82F6" />}
                {service.type === 'logistics' && <Building size={24} color="#8B5CF6" />}
              </View>
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceName}>{service.name}</Text>
                <Text style={styles.serviceExperience}>{service.experience} deneyim</Text>
                <View style={styles.ratingContainer}>
                  <Star size={16} color="#F59E0B" fill="#F59E0B" />
                  <Text style={styles.rating}>{service.rating}</Text>
                </View>
              </View>
              <View style={styles.statusContainer}>
                <View style={[styles.statusIndicator, { backgroundColor: service.isAvailable ? '#10B981' : '#EF4444' }]} />
                <Text style={styles.statusText}>{service.isAvailable ? 'Müsait' : 'Meşgul'}</Text>
              </View>
            </View>

            <View style={styles.serviceContent}>
              <Text style={styles.serviceContentTitle}>Nakliye İçeriği:</Text>
              <Text style={styles.serviceContentText}>
                {service.type === 'moving' ? 'Ev eşyaları, mobilya, beyaz eşya, kişisel eşyalar' :
                 service.type === 'cargo' ? 'Küçük paketler, belgeler, değerli eşyalar, hızlı teslimat' :
                 'Büyük hacimli yükler, endüstriyel malzemeler, uluslararası kargo'}
              </Text>
            </View>

            <View style={styles.specialtiesContainer}>
              {service.specialties.map((specialty, index) => (
                <View key={index} style={styles.specialtyTag}>
                  <Text style={styles.specialtyText}>{specialty}</Text>
                </View>
              ))}
            </View>

            <View style={styles.serviceDetails}>
              <View style={styles.detailItem}>
                <Weight size={16} color="#6B7280" />
                <Text style={styles.detailLabel}>Kapasite</Text>
                <Text style={styles.detailValue}>{service.capacity}</Text>
              </View>
              <View style={styles.detailItem}>
                <DollarSign size={16} color="#6B7280" />
                <Text style={styles.detailLabel}>Fiyat</Text>
                <Text style={styles.detailValue}>{service.price}</Text>
              </View>
            </View>

            <TouchableOpacity 
              style={[styles.callButton, !service.isAvailable && styles.disabledButton]} 
              onPress={() => handleCallTransport(service.phone)}
              disabled={!service.isAvailable}
            >
              <Phone size={18} color="#FFFFFF" />
              <Text style={styles.callButtonText}>
                {service.isAvailable ? 'Ara ve Rezervasyon Yap' : 'Şu Anda Müsait Değil'}
              </Text>
            </TouchableOpacity>
          </View>
        ))}

        <View style={styles.infoSection}>
          <View style={styles.infoCard}>
            <Calendar size={24} color="#EF4444" />
            <View style={styles.infoContent}>
              <Text style={styles.infoTitle}>Rezervasyon Önerisi</Text>
              <Text style={styles.infoText}>
                Nakliye hizmetleri için en az 24 saat önceden rezervasyon yapmanızı öneririz.
                Özellikle hafta sonları ve tatil günlerinde erken rezervasyon önemlidir.
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.statsSection}>
          <Text style={styles.statsSectionTitle}>İstatistikler</Text>
          <View style={styles.statsGrid}>
            {quickStats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <View key={index} style={styles.statCard}>
                  <Icon size={16} color="#EF4444" />
                  <Text style={styles.statValue}>{stat.value}</Text>
                  <Text style={styles.statLabel}>{stat.label}</Text>
                </View>
              );
            })}
          </View>
        </View>

        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingVertical: 24,
    paddingHorizontal: 20,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginTop: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#FECACA',
    marginTop: 4,
  },
  userTypeSection: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  routeSection: {
    marginBottom: 16,
  },
  routeSectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 12,
  },
  routeInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  routeInputWrapper: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  routeInput: {
    flex: 1,
    marginLeft: 8,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  routeArrow: {
    paddingHorizontal: 8,
  },
  routeArrowText: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: '#6B7280',
  },
  headerActions: {
    alignItems: 'flex-end',
  },
  registerButton: {
    backgroundColor: '#EF4444',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  registerButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
  statsSection: {
    paddingHorizontal: 20,
    paddingVertical: 20,
    backgroundColor: '#FFFFFF',
    marginTop: 20,
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statCard: {
    alignItems: 'center',
    flex: 1,
  },
  statValue: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginTop: 3,
  },
  statLabel: {
    fontSize: 10,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginTop: 2,
    textAlign: 'center',
  },
  searchSection: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  typeSection: {
    backgroundColor: '#FFFFFF',
    paddingBottom: 16,
  },
  typeContent: {
    paddingHorizontal: 20,
  },
  typeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    marginRight: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  activeTypeButton: {
    backgroundColor: '#EF4444',
    borderColor: '#EF4444',
  },
  typeText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 6,
  },
  activeTypeText: {
    color: '#FFFFFF',
  },
  servicesContainer: {
    flex: 1,
  },
  resultsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  resultsText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  quoteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EF4444',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  quoteButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 4,
  },
  serviceCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginHorizontal: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  serviceHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  serviceIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  serviceExperience: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 4,
  },
  statusContainer: {
    alignItems: 'center',
  },
  statusIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginBottom: 4,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  specialtiesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 16,
  },
  specialtyTag: {
    backgroundColor: '#FEF3F2',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 4,
  },
  specialtyText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#EF4444',
  },
  serviceDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  detailLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 8,
    marginRight: 8,
  },
  detailValue: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  callButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#EF4444',
    paddingVertical: 12,
    borderRadius: 12,
  },
  disabledButton: {
    backgroundColor: '#9CA3AF',
  },
  callButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
  providerSection: {
    paddingHorizontal: 20,
  },
  providerCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  providerTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginTop: 16,
    marginBottom: 8,
  },
  providerDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 20,
  },
  registerButton: {
    backgroundColor: '#EF4444',
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderRadius: 12,
  },
  registerButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  providerBenefits: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  benefitsTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  benefitItem: {
    marginBottom: 8,
  },
  benefitText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 20,
  },
  infoSection: {
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  infoCard: {
    backgroundColor: '#FEF3F2',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#FECACA',
  },
  infoContent: {
    flex: 1,
    marginLeft: 16,
  },
  infoTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#B91C1C',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#B91C1C',
    lineHeight: 20,
  },
  bottomPadding: {
    height: 20,
  },
});