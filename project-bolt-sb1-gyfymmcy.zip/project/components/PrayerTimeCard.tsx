import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

interface PrayerTimeCardProps {
  name: string;
  time: string;
  isNext: boolean;
  isActive: boolean;
}

export default function PrayerTimeCard({ name, time, isNext, isActive }: PrayerTimeCardProps) {
  return (
    <View style={[
      styles.card,
      isActive && styles.activeCard,
      isNext && styles.nextCard
    ]}>
      <Text style={[
        styles.prayerName,
        isActive && styles.activeText,
        isNext && styles.nextText
      ]}>
        {name}
      </Text>
      <Text style={[
        styles.prayerTime,
        isActive && styles.activeText,
        isNext && styles.nextText
      ]}>
        {time}
      </Text>
      {isNext && (
        <View style={styles.nextIndicator}>
          <Text style={styles.nextLabel}>Sonraki</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    marginVertical: 6,
    marginHorizontal: 4,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
    alignItems: 'center',
    minWidth: 120,
  },
  activeCard: {
    backgroundColor: '#10B981',
  },
  nextCard: {
    backgroundColor: '#DC2626',
  },
  prayerName: {
    fontSize: 16,
    fontFamily: 'Cairo-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  prayerTime: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  activeText: {
    color: '#FFFFFF',
  },
  nextText: {
    color: '#FFFFFF',
  },
  nextIndicator: {
    position: 'absolute',
    top: -8,
    right: -8,
    backgroundColor: '#F59E0B',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  nextLabel: {
    fontSize: 10,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
});