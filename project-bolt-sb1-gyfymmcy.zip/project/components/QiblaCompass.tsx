import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { Navigation } from 'lucide-react-native';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  withSpring,
  interpolate
} from 'react-native-reanimated';

const { width } = Dimensions.get('window');

export default function QiblaCompass() {
  const [heading, setHeading] = useState(0);
  const [qiblaDirection, setQiblaDirection] = useState(45); // Simulated qibla direction
  
  const rotation = useSharedValue(0);
  const qiblaRotation = useSharedValue(0);

  useEffect(() => {
    // Simulate compass updates
    const interval = setInterval(() => {
      const newHeading = Math.random() * 360;
      setHeading(newHeading);
      rotation.value = withSpring(-newHeading);
      qiblaRotation.value = withSpring(qiblaDirection - newHeading);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const compassStyle = useAnimatedStyle(() => {
    return {
      transform: [{ rotate: `${rotation.value}deg` }],
    };
  });

  const qiblaStyle = useAnimatedStyle(() => {
    return {
      transform: [{ rotate: `${qiblaRotation.value}deg` }],
    };
  });

  return (
    <View style={styles.container}>
      <View style={styles.compassContainer}>
        <Animated.View style={[styles.compass, compassStyle]}>
          {/* Compass markings */}
          <View style={styles.compassMarkings}>
            <Text style={[styles.directionText, styles.northText]}>N</Text>
            <Text style={[styles.directionText, styles.eastText]}>E</Text>
            <Text style={[styles.directionText, styles.southText]}>S</Text>
            <Text style={[styles.directionText, styles.westText]}>W</Text>
          </View>
          
          {/* Compass needle */}
          <View style={styles.needle}>
            <View style={styles.needleNorth} />
            <View style={styles.needleSouth} />
          </View>
        </Animated.View>
        
        {/* Qibla indicator */}
        <Animated.View style={[styles.qiblaIndicator, qiblaStyle]}>
          <Navigation size={32} color="#10B981" fill="#10B981" />
        </Animated.View>
      </View>
      
      <View style={styles.infoContainer}>
        <Text style={styles.headingText}>Yön: {Math.round(heading)}°</Text>
        <Text style={styles.qiblaText}>Kıble: {Math.round(qiblaDirection)}°</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: 20,
  },
  compassContainer: {
    width: width * 0.7,
    height: width * 0.7,
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },
  compass: {
    width: '100%',
    height: '100%',
    borderRadius: width * 0.35,
    backgroundColor: '#F9FAFB',
    borderWidth: 4,
    borderColor: '#E5E7EB',
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },
  compassMarkings: {
    position: 'absolute',
    width: '100%',
    height: '100%',
  },
  directionText: {
    position: 'absolute',
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  northText: {
    top: 20,
    left: '50%',
    marginLeft: -10,
    color: '#DC2626',
  },
  eastText: {
    right: 20,
    top: '50%',
    marginTop: -10,
  },
  southText: {
    bottom: 20,
    left: '50%',
    marginLeft: -10,
  },
  westText: {
    left: 20,
    top: '50%',
    marginTop: -10,
  },
  needle: {
    position: 'absolute',
    width: 4,
    height: '60%',
    alignItems: 'center',
  },
  needleNorth: {
    width: 0,
    height: 0,
    borderLeftWidth: 8,
    borderRightWidth: 8,
    borderBottomWidth: 40,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: '#DC2626',
  },
  needleSouth: {
    width: 0,
    height: 0,
    borderLeftWidth: 8,
    borderRightWidth: 8,
    borderTopWidth: 40,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderTopColor: '#6B7280',
    marginTop: 4,
  },
  qiblaIndicator: {
    position: 'absolute',
    top: 20,
  },
  infoContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  headingText: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 8,
  },
  qiblaText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#10B981',
  },
});