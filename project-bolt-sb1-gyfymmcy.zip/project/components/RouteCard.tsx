import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { MapPin, Clock, Navigation, Fuel } from 'lucide-react-native';

interface RouteInfo {
  id: string;
  from: string;
  to: string;
  distance: string;
  duration: string;
  roadCondition: 'good' | 'moderate' | 'poor';
  trafficLevel: 'low' | 'medium' | 'high';
  tollCost: string;
  fuelCost: string;
}

interface RouteCardProps {
  route: RouteInfo;
}

export default function RouteCard({ route }: RouteCardProps) {
  return (
    <View style={styles.card}>
      <View style={styles.routeHeader}>
        <View style={styles.locationContainer}>
          <View style={styles.locationItem}>
            <MapPin size={16} color="#10B981" />
            <Text style={styles.locationText}>{route.from}</Text>
          </View>
          <View style={styles.routeLine} />
          <View style={styles.locationItem}>
            <MapPin size={16} color="#DC2626" />
            <Text style={styles.locationText}>{route.to}</Text>
          </View>
        </View>
      </View>
      
      <View style={styles.routeDetails}>
        <View style={styles.detailItem}>
          <Navigation size={20} color="#3B82F6" />
          <View style={styles.detailInfo}>
            <Text style={styles.detailLabel}>Mesafe</Text>
            <Text style={styles.detailValue}>{route.distance}</Text>
          </View>
        </View>
        
        <View style={styles.detailItem}>
          <Clock size={20} color="#6B7280" />
          <View style={styles.detailInfo}>
            <Text style={styles.detailLabel}>Süre</Text>
            <Text style={styles.detailValue}>{route.duration}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  routeHeader: {
    marginBottom: 20,
  },
  locationContainer: {
    position: 'relative',
  },
  locationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  locationText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
    marginLeft: 12,
  },
  routeLine: {
    position: 'absolute',
    left: 8,
    top: 24,
    bottom: 24,
    width: 2,
    backgroundColor: '#E5E7EB',
  },
  routeDetails: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  detailInfo: {
    marginLeft: 12,
  },
  detailLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
});