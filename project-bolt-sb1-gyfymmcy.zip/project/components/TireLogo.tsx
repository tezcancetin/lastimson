import React from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import Svg, { Circle, Path, Ellipse, G } from 'react-native-svg';

interface TireLogoProps {
  size?: number;
  color?: string;
}

export default function TireLogo({ size = 60, color = '#DC2626' }: TireLogoProps) {
  // Web platformu için basit animasyon, native için reanimated kullanılabilir
  const AnimatedWorld = Platform.OS === 'web' ? 
    ({ children }: { children: React.ReactNode }) => <View>{children}</View> :
    ({ children }: { children: React.ReactNode }) => <View>{children}</View>;

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      <Svg width={size} height={size} viewBox="0 0 100 100">
        {/* Outer tire - darker */}
        <Circle
          cx="50"
          cy="50"
          r="45"
          fill="none"
          stroke="#0F172A"
          strokeWidth="10"
        />
        
        {/* Inner tire - darker */}
        <Circle
          cx="50"
          cy="50"
          r="30"
          fill="none"
          stroke="#1E293B"
          strokeWidth="6"
        />
        
        {/* Tire treads - darker and more */}
        <Circle cx="50" cy="8" r="2.5" fill="#0F172A" />
        <Circle cx="92" cy="50" r="2.5" fill="#0F172A" />
        <Circle cx="50" cy="92" r="2.5" fill="#0F172A" />
        <Circle cx="8" cy="50" r="2.5" fill="#0F172A" />
        <Circle cx="76" cy="24" r="2" fill="#0F172A" />
        <Circle cx="76" cy="76" r="2" fill="#0F172A" />
        <Circle cx="24" cy="76" r="2" fill="#0F172A" />
        <Circle cx="24" cy="24" r="2" fill="#0F172A" />
        <Circle cx="65" cy="15" r="1.5" fill="#0F172A" />
        <Circle cx="85" cy="35" r="1.5" fill="#0F172A" />
        <Circle cx="85" cy="65" r="1.5" fill="#0F172A" />
        <Circle cx="65" cy="85" r="1.5" fill="#0F172A" />
        <Circle cx="35" cy="85" r="1.5" fill="#0F172A" />
        <Circle cx="15" cy="65" r="1.5" fill="#0F172A" />
        <Circle cx="15" cy="35" r="1.5" fill="#0F172A" />
        <Circle cx="35" cy="15" r="1.5" fill="#0F172A" />
        
        {/* Static world inside (web uyumlu) */}
        <G>
          {/* World circle */}
          <Circle
            cx="50"
            cy="50"
            r="22"
            fill="#1E40AF"
            stroke="#1E293B"
            strokeWidth="1"
          />
          
          {/* Continents */}
          <Path
            d="M 35 35 Q 42 28, 50 35 Q 58 42, 65 35 Q 63 50, 58 58 Q 50 65, 42 58 Q 35 50, 35 35 Z"
            fill="#10B981"
          />
          <Path
            d="M 30 50 Q 36 47, 39 52 Q 34 60, 30 57 Q 26 52, 30 50 Z"
            fill="#10B981"
          />
          <Path
            d="M 58 30 Q 65 27, 68 32 Q 63 40, 58 37 Q 53 32, 58 30 Z"
            fill="#10B981"
          />
          <Path
            d="M 45 60 Q 52 58, 55 63 Q 50 68, 45 66 Q 40 63, 45 60 Z"
            fill="#10B981"
          />
        </G>
        
        {/* Crescent moon */}
        <Path
          d="M 60 35 C 55 30, 55 45, 60 40 C 65 37.5, 65 37.5, 60 35 Z"
          fill={color}
        />
        
        {/* Crescent tip */}
        <Ellipse
          cx="67"
          cy="37.5"
          rx="2"
          ry="1.5"
          fill={color}
        />
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});