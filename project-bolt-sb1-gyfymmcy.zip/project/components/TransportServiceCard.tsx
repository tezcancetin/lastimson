import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Star, Phone, Truck, Package, Building } from 'lucide-react-native';

interface TransportService {
  id: string;
  name: string;
  type: 'moving' | 'cargo' | 'logistics';
  rating: number;
  price: string;
  capacity: string;
  phone: string;
  isAvailable: boolean;
}

interface TransportServiceCardProps {
  service: TransportService;
  onCall: () => void;
}

export default function TransportServiceCard({ service, onCall }: TransportServiceCardProps) {
  const getServiceIcon = (type: string) => {
    switch (type) {
      case 'moving': return Truck;
      case 'cargo': return Package;
      case 'logistics': return Building;
      default: return Truck;
    }
  };

  const getServiceTypeText = (type: string) => {
    switch (type) {
      case 'moving': return 'Ev Taşıma';
      case 'cargo': return 'Kargo';
      case 'logistics': return 'Lojistik';
      default: return 'Nakliye';
    }
  };

  const getServiceColor = (type: string) => {
    switch (type) {
      case 'moving': return '#10B981';
      case 'cargo': return '#3B82F6';
      case 'logistics': return '#8B5CF6';
      default: return '#6B7280';
    }
  };

  const ServiceIcon = getServiceIcon(service.type);

  return (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <View style={[styles.serviceIcon, { backgroundColor: `${getServiceColor(service.type)}20` }]}>
          <ServiceIcon size={24} color={getServiceColor(service.type)} />
        </View>
        <View style={styles.serviceInfo}>
          <Text style={styles.serviceName}>{service.name}</Text>
          <Text style={styles.serviceType}>{getServiceTypeText(service.type)}</Text>
          <View style={styles.ratingContainer}>
            <Star size={16} color="#F59E0B" fill="#F59E0B" />
            <Text style={styles.rating}>{service.rating}</Text>
          </View>
        </View>
        <View style={styles.statusContainer}>
          <View style={[styles.statusIndicator, { backgroundColor: service.isAvailable ? '#10B981' : '#EF4444' }]} />
          <Text style={styles.statusText}>{service.isAvailable ? 'Müsait' : 'Meşgul'}</Text>
        </View>
      </View>
      
      <View style={styles.serviceDetails}>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Fiyat</Text>
          <Text style={styles.detailValue}>{service.price}</Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Kapasite</Text>
          <Text style={styles.detailValue}>{service.capacity}</Text>
        </View>
      </View>
      
      <TouchableOpacity 
        style={[styles.callButton, !service.isAvailable && styles.disabledButton]} 
        onPress={onCall}
        disabled={!service.isAvailable}
      >
        <Phone size={18} color="#FFFFFF" />
        <Text style={styles.callButtonText}>
          {service.isAvailable ? 'Ara ve Rezervasyon Yap' : 'Şu Anda Müsait Değil'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  serviceIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  serviceType: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginLeft: 4,
  },
  statusContainer: {
    alignItems: 'center',
  },
  statusIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginBottom: 4,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  serviceDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
  },
  detailItem: {
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  callButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#3B82F6',
    paddingVertical: 12,
    borderRadius: 12,
  },
  disabledButton: {
    backgroundColor: '#9CA3AF',
  },
  callButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
});