import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Sun, Cloud, CloudRain, Eye, Wind, Droplets, MapPin } from 'lucide-react-native';

interface WeatherInfo {
  location: string;
  temperature: number;
  condition: 'sunny' | 'cloudy' | 'rainy';
  humidity: number;
  windSpeed: number;
  visibility: string;
}

interface WeatherCardProps {
  weather: WeatherInfo;
}

export default function WeatherCard({ weather }: WeatherCardProps) {
  const getWeatherIcon = (condition: string) => {
    switch (condition) {
      case 'sunny': return Sun;
      case 'cloudy': return Cloud;
      case 'rainy': return CloudRain;
      default: return Cloud;
    }
  };

  const getWeatherColor = (condition: string) => {
    switch (condition) {
      case 'sunny': return '#F59E0B';
      case 'cloudy': return '#6B7280';
      case 'rainy': return '#3B82F6';
      default: return '#6B7280';
    }
  };

  const getConditionText = (condition: string) => {
    switch (condition) {
      case 'sunny': return 'Güneşli';
      case 'cloudy': return 'Bulutlu';
      case 'rainy': return 'Yağmurlu';
      default: return 'Bilinmiyor';
    }
  };

  const getBackgroundColor = (condition: string) => {
    switch (condition) {
      case 'sunny': return '#FEF3C7';
      case 'cloudy': return '#F3F4F6';
      case 'rainy': return '#DBEAFE';
      default: return '#F3F4F6';
    }
  };

  const WeatherIcon = getWeatherIcon(weather.condition);

  return (
    <View style={styles.card}>
      <View style={[styles.weatherBanner, { backgroundColor: getBackgroundColor(weather.condition) }]}>
        <MapPin size={16} color="#6B7280" />
        <Text style={styles.locationText}>{weather.location}</Text>
      </View>
      
      <View style={styles.weatherMain}>
        <View style={styles.temperatureSection}>
          <WeatherIcon size={48} color={getWeatherColor(weather.condition)} />
          <View style={styles.tempInfo}>
            <Text style={styles.temperature}>{weather.temperature}°C</Text>
            <Text style={styles.conditionText}>{getConditionText(weather.condition)}</Text>
          </View>
        </View>
      </View>
      
      <View style={styles.weatherDetails}>
        <View style={styles.detailItem}>
          <View style={styles.detailIcon}>
            <Droplets size={16} color="#3B82F6" />
          </View>
          <Text style={styles.detailLabel}>Nem</Text>
          <Text style={styles.detailValue}>{weather.humidity}%</Text>
        </View>
        
        <View style={styles.detailItem}>
          <View style={styles.detailIcon}>
            <Wind size={16} color="#6B7280" />
          </View>
          <Text style={styles.detailLabel}>Rüzgar</Text>
          <Text style={styles.detailValue}>{weather.windSpeed} km/h</Text>
        </View>
        
        <View style={styles.detailItem}>
          <View style={styles.detailIcon}>
            <Eye size={16} color="#10B981" />
          </View>
          <Text style={styles.detailLabel}>Görüş</Text>
          <Text style={styles.detailValue}>{weather.visibility}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
    overflow: 'hidden',
  },
  weatherBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  locationText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginLeft: 8,
  },
  weatherMain: {
    padding: 20,
    paddingTop: 16,
  },
  temperatureSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  tempInfo: {
    marginLeft: 16,
    flex: 1,
  },
  temperature: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  conditionText: {
    fontSize: 18,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  weatherDetails: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
    paddingTop: 16,
  },
  detailItem: {
    alignItems: 'center',
    flex: 1,
  },
  detailIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F9FAFB',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  detailLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
});